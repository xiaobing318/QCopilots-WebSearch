提供网页搜索、网页阅读和页内查找，支持 REST、MCP HTTP 与 stdio 接入。

| 下载文件 | 用途 |
| --- | --- |
| `QCopilots-WebSearch-0.1.4-win64.zip` | Windows 11 amd64 便携版，解压使用 |
| `QCopilots-WebSearch-0.1.4-win64.msi` | Windows 11 amd64 安装包 |
| `qcopilots-websearch_0.1.4_amd64.deb` | Ubuntu 26.04 amd64 安装包 |
| `QCopilots-WebSearch-0.1.4-corresponding-sources.zip` | 项目、Qt 和 OpenSSL 的配套源码，用于构建和替换共享库 |
| `SHA256SUMS` | 上述四个下载文件的 SHA-256 校验清单 |

部署前请阅读[使用说明](https://github.com/xiaobing318/QCopilots-WebSearch/blob/v0.1.4/README.md)和[部署指南](https://github.com/xiaobing318/QCopilots-WebSearch/blob/v0.1.4/docs/deployment.md)，搜索依赖单独部署的 SearXNG。安装包未签名，公网搜索结果受上游引擎可用性影响。

[QGIS 适配插件](https://github.com/xiaobing318/QGIS/commit/f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d) · [验收记录与已知限制](https://github.com/xiaobing318/QCopilots-WebSearch/tree/7f52895eb9e3294f92699748c15eb34bbe7c3693/release-evidence/v0.1.4)