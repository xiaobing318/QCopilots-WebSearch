"""User-authorized one-time Release display operation, not product build tooling."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time, zipfile
import httpx

root=Path(__file__).resolve().parents[1]
folder=root/'work/release-display'
plan=json.loads((folder/'prepared/display-plan.json').read_bytes())
original={a['name']:a for a in json.loads((folder/'assets-before.json').read_bytes())}
source_name=plan['corresponding_sources']['asset_name']
parser=argparse.ArgumentParser()
parser.add_argument('--VerifyOnly',action='store_true')
args=parser.parse_args()
def need(value,message):
    if not value: raise RuntimeError(message)
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
audit=json.loads((folder/'public-audit-verification.json').read_bytes())
need(audit['commit']=='7f52895eb9e3294f92699748c15eb34bbe7c3693'
     and audit['immutable_public_bytes_equal_git_blobs'],'Public audit not verified')
need(any(f['path'].endswith('/release-assets-audit.zip') and f['sha256']==plan['audit']['sha256'] for f in audit['files']),
     'Wrong audit archive')
environment={**os.environ,'GCM_INTERACTIVE':'never','GIT_TERMINAL_PROMPT':'0'}
credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\nusername=xiaobing318\n\n',
                          text=True,capture_output=True,check=True,timeout=30,env=environment)
token=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)['password']
headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json'}
base='https://api.github.com/repos/xiaobing318/QCopilots-WebSearch'
client=httpx.Client(timeout=90,follow_redirects=False)
def api(method,path,**kwargs):
    response=client.request(method,base+path,headers=headers,**kwargs)
    need(response.is_success,f'GitHub API {method} {path} returned {response.status_code}')
    return response.json() if response.content else None
def identity():
    release=api('GET','/releases/446672881')
    need(release['draft'] is False and release['published_at'] and release['tag_name']=='v0.1.4'
         and release['target_commitish']==plan['source_commit'],'Release identity changed')
    return release
def assets():
    result=[]
    for page in range(1,11):
        batch=api('GET',f'/releases/446672881/assets?per_page=100&page={page}')
        result+=batch
        if len(batch)<100: break
    else: raise RuntimeError('Asset listing truncated')
    need(len(result)==len({a['name'] for a in result})==len({a['id'] for a in result}),'Duplicate remote assets')
    return {a['name']:a for a in result}
def fields(a): return {k:a.get(k) for k in ('id','name','size','state','digest')}
identity()
current=assets()
need(set(current)<=set(original)|{source_name},'Unexpected assets before presentation cleanup')
packages=set(plan['visible_assets'])-{source_name,'SHA256SUMS'}
need(packages|{source_name}<=set(current),'A retained download is missing')
for name,entry in original.items():
    if name not in current: continue  # Already removed, exact bytes remain in the public audit.
    if name=='SHA256SUMS' and current[name]['state']=='uploaded' and current[name]['digest']=='sha256:'+plan['visible_assets'][name]:
        continue  # Resume after replacement. Its actual bytes are checked below.
    need(fields(current[name])==fields(entry),'Original remote asset changed: '+name)
source=current[source_name]
need(source['state']=='uploaded' and source['digest']=='sha256:'+plan['corresponding_sources']['sha256']
     and source['size']==plan['corresponding_sources']['bytes'],'Source bundle upload is incomplete or differs')
download=folder/'downloaded-source.zip'
if not download.exists():
    # GitHub returns a public signed redirect. Never send Git credentials to it.
    for attempt in range(4):
        try:
            with client.stream('GET',base+'/releases/assets/'+str(source['id']),
                               headers={**headers,'Accept':'application/octet-stream'}) as redirect:
                need(redirect.status_code==302,'Expected exact source asset download redirect')
                url=redirect.headers['Location']
            need(url.startswith('https://'),'Non-HTTPS source download')
            with httpx.Client(timeout=httpx.Timeout(60,connect=20),follow_redirects=False) as public:
                with public.stream('GET',url,headers={'Range':'bytes=0-0'}) as response:
                    need(response.status_code==206 and response.headers.get('Content-Range')==f"bytes 0-0/{source['size']}",
                         'Source download does not support verified ranges')
                    need(len(response.read())==1,'Invalid initial range')
            break
        except httpx.TransportError:
            if attempt==3: raise RuntimeError('Source download connection failed after four attempts') from None
            time.sleep(attempt+1)
    parts=folder/'source-ranges'
    parts.mkdir(exist_ok=True)
    chunk=4*1024*1024
    count=(source['size']+chunk-1)//chunk
    def fetch(index):
        first,last=index*chunk,min(source['size'],(index+1)*chunk)-1
        for attempt in range(4):
            try:
                with httpx.Client(timeout=httpx.Timeout(90,connect=20),follow_redirects=False) as public:
                    response=public.get(url,headers={'Range':f'bytes={first}-{last}'})
                    need(response.status_code==206 and response.headers.get('Content-Range')==f"bytes {first}-{last}/{source['size']}",
                         'Source range identity mismatch')
                    need(len(response.content)==last-first+1,'Source range size mismatch')
                    (parts/str(index)).write_bytes(response.content)
                break
            except httpx.TransportError:
                if attempt==3: raise RuntimeError('Source range connection failed: '+str(index)) from None
                time.sleep(attempt+1)
        return index
    with ThreadPoolExecutor(max_workers=8) as pool:
        for completed,_ in enumerate(pool.map(fetch,range(count)),1):
            if completed%5==0 or completed==count: print(f'Verified source ranges {completed}/{count}',flush=True)
    with download.open('xb') as output:
        for index in range(count): output.write((parts/str(index)).read_bytes())
need(download.stat().st_size==source['size'] and sha(download)==plan['corresponding_sources']['sha256'],
     'Downloaded source bundle differs')
with zipfile.ZipFile(download) as archive:
    members=plan['corresponding_sources']['members']
    need(len(archive.infolist())==len(members) and set(archive.namelist())==set(members),'Source members differ')
    for name,entry in members.items():
        raw=archive.read(name)
        need(len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'Source member differs')
verified={'asset_id':source['id'],'name':source_name,'bytes':source['size'],'sha256':sha(download),
          'full_remote_bytes_downloaded':True,'all_original_source_archives_preserved':True}
(folder/'source-download-verification.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete source bundle downloaded and all members verified',flush=True)
if args.VerifyOnly:
    client.close()
    raise SystemExit(0)
identity()
need({n:fields(a) for n,a in assets().items()}=={n:fields(a) for n,a in current.items()},'Asset state changed before cleanup')
removed=[]
for name,entry in sorted(original.items()):
    if name in plan['visible_assets']: continue
    if name in current:
        need(fields(api('GET','/releases/assets/'+str(entry['id'])))==fields(entry),'Deletion target changed')
        api('DELETE','/releases/assets/'+str(entry['id']))
    removed.append({'name':name,'id':entry['id'],'sha256':entry['digest'].removeprefix('sha256:'),
                    'already_absent_at_resume':name not in current})
    (folder/'removed-assets.json').write_text(json.dumps(removed,indent=2)+'\n',encoding='utf-8',newline='\n')
    if len(removed)%10==0: print(f'Confirmed removal of {len(removed)} archived download entries',flush=True)
need(len(removed)==76,'Unexpected removal count')
old=original['SHA256SUMS']
new_sums=(folder/'prepared/SHA256SUMS').read_bytes()
need(hashlib.sha256(new_sums).hexdigest()==plan['visible_assets']['SHA256SUMS'],'New checksums changed')
present=assets().get('SHA256SUMS')
if present and fields(present)==fields(old):
    api('DELETE','/releases/assets/'+str(old['id']))
    present=None
if present:
    need(present['state']=='uploaded' and present['digest']=='sha256:'+plan['visible_assets']['SHA256SUMS'],
         'Unexpected replacement checksum state')
    checksum_asset=present
else:
    response=client.post('https://uploads.github.com/repos/xiaobing318/QCopilots-WebSearch/releases/446672881/assets',
        params={'name':'SHA256SUMS'},headers={**headers,'Content-Type':'application/octet-stream'},content=new_sums)
    need(response.is_success,'Checksum upload failed: '+str(response.status_code))
    checksum_asset=response.json()
need(checksum_asset['name']=='SHA256SUMS' and checksum_asset['digest']=='sha256:'+plan['visible_assets']['SHA256SUMS'],
     'New checksum acknowledgement differs')
for attempt in range(4):
    try:
        response=client.get(base+'/releases/assets/'+str(checksum_asset['id']),
                            headers={**headers,'Accept':'application/octet-stream'})
        if response.status_code==302:
            location=response.headers['Location']
            need(location.startswith('https://'),'Non-HTTPS checksum redirect')
            with httpx.Client(timeout=httpx.Timeout(60,connect=20),follow_redirects=False) as public:
                response=public.get(location)
        need(response.is_success and response.content==new_sums,'Remote checksum bytes differ')
        break
    except httpx.TransportError:
        if attempt==3: raise RuntimeError('Checksum readback connection failed after retries') from None
        time.sleep(attempt+1)
notes=(root/'outputs/resume-2026-11-15/Release-v0.1.4-notes.md').read_text('utf-8')
api('PATCH','/releases/446672881',json={'body':notes})
release=identity()
final=assets()
need(set(final)==set(plan['visible_assets']),'Final download names differ')
for name,digest in plan['visible_assets'].items():
    need(final[name]['state']=='uploaded' and final[name]['digest']=='sha256:'+digest,'Final asset differs')
    if name in original and name!='SHA256SUMS': need(fields(final[name])==fields(original[name]),'Installer changed')
need(release['body']==notes,'Release notes differ')
record={'release_id':446672881,'tag':'v0.1.4','url':release['html_url'],'source_commit':plan['source_commit'],
        'audit_commit':audit['commit'],'visible_uploaded_asset_count':5,'visible_assets':{n:fields(a) for n,a in final.items()},
        'removed_count':len(removed),'replaced_checksums_asset_id':old['id'],
        'remote_source_download_verification':verified,'archived_original_audit_files':74,
        'all_original_80_assets_preserved':True,'installation_packages_unchanged':True,'product_rebuilt':False,
        'notes_sha256':hashlib.sha256(notes.encode()).hexdigest(),
        'github_automatic_source_links':'GitHub-generated source ZIP/TAR links are separate from uploaded assets.'}
(folder/'display-result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
client.close()
print(json.dumps(record,indent=2),flush=True)
