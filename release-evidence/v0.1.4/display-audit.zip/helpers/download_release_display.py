"""Retain exact public Release bytes before simplifying the download list."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib, json, time
import shutil
import httpx
root=Path(__file__).resolve().parents[1]
folder=root/'work/release-display'
entries=json.loads((folder/'assets-before.json').read_bytes())
keep={'QCopilots-WebSearch-0.1.4-win64.msi','QCopilots-WebSearch-0.1.4-win64.zip','qcopilots-websearch_0.1.4_amd64.deb'}
cache=folder/'original'
cache.mkdir(exist_ok=True)
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def fetch(entry):
    target=cache/entry['name']
    expected=entry['digest'].removeprefix('sha256:')
    if target.exists():
        if target.stat().st_size==entry['size'] and sha(target)==expected: return entry['name']
        raise RuntimeError('Existing file differs: '+entry['name'])
    candidates=list((root/'work/release-43805306130/artifacts').rglob(entry['name']))
    if entry['name']=='windows11-evidence.json':
        candidates.append(Path(r'C:\Dev\github-repos\QCopilots-WebSearch\release-evidence\v0.1.4\windows11.json'))
    for candidate in candidates:
        if candidate.is_file() and candidate.stat().st_size==entry['size'] and sha(candidate)==expected:
            shutil.copyfile(candidate,target)
            return entry['name']
    last=None
    for attempt in range(3):
        try:
            partial=target.with_name(target.name+'.partial')
            with httpx.Client(timeout=httpx.Timeout(90,connect=20),follow_redirects=True) as client:
                with client.stream('GET',entry['browser_download_url']) as response:
                    response.raise_for_status()
                    received=0
                    with partial.open('wb') as stream:
                        for block in response.iter_bytes(1024*1024):
                            received+=len(block)
                            if received>entry['size']: raise RuntimeError('Oversized asset')
                            stream.write(block)
            if received!=entry['size'] or sha(partial)!=expected: raise RuntimeError('Asset checksum differs')
            partial.replace(target)
            return entry['name']
        except Exception as error:
            last=error
            time.sleep(attempt+1)
    raise RuntimeError('Unable to preserve '+entry['name']) from last
selected=[e for e in entries if e['name'] not in keep]
count=0
with ThreadPoolExecutor(max_workers=6) as pool:
    for future in as_completed([pool.submit(fetch,e) for e in selected]):
        name=future.result()
        count+=1
        if count%10==0 or count==len(selected): print(f'Preserved {count}/{len(selected)} assets, latest {name}',flush=True)
record={'original_release_id':446672881,'preserved_assets':len(selected),
        'files':{e['name']:{'bytes':e['size'],'sha256':sha(cache/e['name']),'original_asset_id':e['id']} for e in selected}}
(folder/'preserved.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('All non-installer asset bytes preserved and verified',flush=True)
