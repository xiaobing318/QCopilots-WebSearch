from pathlib import Path
import hashlib,json,subprocess
import httpx
root=Path(__file__).resolve().parents[1]
folder=root/'work/release-display'
commit='7f52895eb9e3294f92699748c15eb34bbe7c3693'
repo=Path(r'C:\Dev\github-repos\QCopilots-WebSearch')
records=[]
for name in ('release-assets-audit.zip','display-plan.json','publication-audit.zip','publication-verification.json'):
    path='release-evidence/v0.1.4/'+name
    expected=subprocess.check_output(['git','-C',str(repo),'cat-file','blob',commit+':'+path])
    response=httpx.get('https://raw.githubusercontent.com/xiaobing318/QCopilots-WebSearch/'+commit+'/'+path,timeout=90)
    response.raise_for_status()
    if response.content!=expected: raise RuntimeError('Published audit differs: '+name)
    records.append({'path':path,'bytes':len(expected),'sha256':hashlib.sha256(expected).hexdigest()})
record={'commit':commit,'immutable_public_bytes_equal_git_blobs':True,'files':records}
(folder/'public-audit-verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record,indent=2))
