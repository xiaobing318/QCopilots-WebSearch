"""Create lossless audit and corresponding-source archives, without rebuilding."""
from pathlib import Path
import hashlib, json, stat, zipfile
root=Path(__file__).resolve().parents[1]
folder=root/'work/release-display'
original=folder/'original'
output=folder/'prepared'
output.mkdir(exist_ok=True)
entries=json.loads((folder/'assets-before.json').read_bytes())
assets={e['name']:e for e in entries}
packages={'QCopilots-WebSearch-0.1.4-win64.msi','QCopilots-WebSearch-0.1.4-win64.zip','qcopilots-websearch_0.1.4_amd64.deb'}
sources={'openssl-3.5.9.tar.gz','qtbase-everywhere-src-6.12.0.tar.xz',
         'QCopilots-WebSearch-3e13f7bd930ffa495e14d50c3556028a21484204-source.tar.gz'}
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
for name in set(assets)-packages:
    assert (original/name).stat().st_size==assets[name]['size']
    assert sha(original/name)==assets[name]['digest'].removeprefix('sha256:')
def bundle(path,members,compressed):
    with zipfile.ZipFile(path,'x') as archive:
        for name,raw in sorted(members.items()):
            entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            entry.create_system=3
            entry.external_attr=(stat.S_IFREG|0o644)<<16
            entry.compress_type=zipfile.ZIP_DEFLATED if compressed else zipfile.ZIP_STORED
            archive.writestr(entry,raw)
    with zipfile.ZipFile(path) as archive:
        assert len(archive.infolist())==len(members)
        for name,raw in members.items(): assert archive.read(name)==raw
    return {'bytes':path.stat().st_size,'sha256':sha(path),
            'members':{n:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in sorted(members.items())}}
source_name='QCopilots-WebSearch-0.1.4-corresponding-sources.zip'
source_members={name:(original/name).read_bytes() for name in sources}
source_members['SOURCE-SHA256SUMS']=''.join(assets[n]['digest'].removeprefix('sha256:')+'  '+n+'\n' for n in sorted(sources)).encode()
source_members['README.md']=b'''# QCopilots-WebSearch 0.1.4 corresponding sources

These are the exact unmodified source archives originally distributed with
v0.1.4, commit 3e13f7bd930ffa495e14d50c3556028a21484204. No binaries were rebuilt.
SOURCE-SHA256SUMS records the original archive bytes.

Extract the QCopilots-WebSearch source archive and follow docs/build.md.
The Qt and OpenSSL archives contain their respective sources and licenses.
The runtime packages retain license texts, notices, Qt build information and
instructions for replacing shared libraries. See docs/licensing.md in the
project source. This bundle changes download packaging only.
'''
source_record=bundle(output/source_name,source_members,False)
audit_members={name:(original/name).read_bytes() for name in set(assets)-packages-sources}
audit_members['ORIGINAL-RELEASE-ASSETS.json']=(folder/'assets-before.json').read_bytes()
audit_members['publication-verification.json']=(root/'work/release-43805306130/publication-43823293370/verification.json').read_bytes()
audit_record=bundle(output/'release-assets-audit.zip',audit_members,True)
retained={name:assets[name]['digest'].removeprefix('sha256:') for name in sorted(packages)}
retained[source_name]=source_record['sha256']
(output/'SHA256SUMS').write_text(''.join(d+'  '+n+'\n' for n,d in sorted(retained.items())),encoding='ascii',newline='\n')
retained['SHA256SUMS']=sha(output/'SHA256SUMS')
mapping={'source_commit':'3e13f7bd930ffa495e14d50c3556028a21484204','release_id':446672881,'tag':'v0.1.4',
         'reason':'User requested only usable downloads and chose one corresponding-source bundle.',
         'original_publication_run':43823293370,'packages_unchanged':True,'product_rebuilt':False,
         'visible_assets':retained,'corresponding_sources':{'asset_name':source_name,**source_record},
         'audit':{'repository_path':'release-evidence/v0.1.4/release-assets-audit.zip',**audit_record},
         'original_assets':{n:{'id':assets[n]['id'],'sha256':assets[n]['digest'].removeprefix('sha256:'),
                    'location':('release asset '+n if n in packages else source_name+'/'+n if n in sources
                                else 'release-assets-audit.zip/'+n)} for n in sorted(assets)}}
(output/'display-plan.json').write_text(json.dumps(mapping,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'source_bundle':{k:v for k,v in source_record.items() if k!='members'},
                 'audit':{k:v for k,v in audit_record.items() if k!='members'},'visible_assets':list(retained)},indent=2))
