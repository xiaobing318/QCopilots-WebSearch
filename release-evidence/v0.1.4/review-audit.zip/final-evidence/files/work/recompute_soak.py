"""Independent recomputation from preserved per-request samples, not PASS flags."""
import argparse
import hashlib
import json
import math
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--Report', type=Path, required=True)
parser.add_argument('--BuildInfo', type=Path, required=True)
parser.add_argument('--Output', type=Path, required=True)
args = parser.parse_args()
report = json.loads(args.Report.read_text('utf-8'))
info = json.loads(args.BuildInfo.read_text('utf-8'))
assert report['seconds_per_phase'] == 300
assert report['clients'] == 5 and report['requests_per_second'] == 2 and report['fixture_delay_ms'] == 100
assert report['resources']['available_cpus'] >= 2 and report['resources']['memory_bytes'] >= 4 * 1024**3
assert report['executable_unchanged'] and report['runtime_unchanged']
assert report['executable_sha256'] == info['executable_sha256'] and report['runtime'] == info['installed_runtime']
host = report['host']
if host['system'] == 'Windows':
    assert host['windows']['product_type'] == 1 and host['windows']['build'] >= 22000
else:
    assert host['linux']['ID'] == 'ubuntu' and host['linux']['VERSION_ID'] == '26.04'
assert [phase['name'] for phase in report['phases']] == ['cold', 'hot']
results = []
for phase in report['phases']:
    assert phase['seconds'] == 300
    request = phase['requests']
    samples = request['samples']
    assert len(samples) == request['attempted'] == request['successful'] == phase['expected_requests'] == 600
    assert {(row['client_index'], row['sequence']) for row in samples} == {(i, j) for i in range(5) for j in range(120)}
    assert all(row['http_status'] == 200 and 'error' not in row and row['cache_hit'] == (phase['name'] == 'hot') for row in samples)
    assert all(row['scheduled_start_offset_ms'] == row['client_index'] * 500 + row['sequence'] * 2500 for row in samples)
    assert all(row['schedule_lag_ms'] <= 250 for row in samples)
    metrics = {}
    for name, threshold in [('requests', 1000), ('health', 200)]:
        stats = phase[name]
        rows = stats['samples']
        assert rows and len(rows) == stats['attempted'] == stats['successful']
        assert all('ms' in row and 'error' not in row and row['http_status'] == 200 for row in rows)
        values = sorted(row['ms'] for row in rows)
        p95 = values[math.ceil(len(values) * .95) - 1]
        assert values == stats['latency_ms'] and p95 == stats['p95_ms'] <= threshold
        assert not stats['errors']
        metrics[name + '_p95_ms'] = p95
    peak = max(phase['rss_samples_bytes'])
    assert 0 < peak == phase['peak_rss_bytes'] <= 512 * 1024**2
    assert phase['fixture_calls'] == (0 if phase['name'] == 'hot' else 600)
    stop = phase['stop']
    assert stop['seconds'] <= 10 and stop['returncode'] == 0 and not stop['forced'] and stop['error'] is None
    results.append({'name': phase['name'], 'requests': 600, 'peak_rss_bytes': peak, 'stop_seconds': stop['seconds'], **metrics})
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
output = {'passed': True, 'report_sha256': sha(args.Report), 'build_info_sha256': sha(args.BuildInfo),
          'verifier_sha256': sha(Path(__file__)), 'host': host, 'phases': results}
args.Output.write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(output, indent=2))
