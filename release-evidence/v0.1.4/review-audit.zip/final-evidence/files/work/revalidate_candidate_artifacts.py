"""Check candidate quality/public evidence against its immutable packaged source."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import tempfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--RunId', type=int, required=True)
parser.add_argument('--Commit', required=True)
parser.add_argument('--Tag', required=True)
parser.add_argument('--Attempt', type=int, default=1)
args = parser.parse_args()
sys.path.insert(0, r'C:\Dev\github-repos\QCopilots-WebSearch\scripts')
from quality_evidence import verify_quality
from public_evidence import verify_public_queries
from verify_release import sums

candidate = root / f'work/release-{args.RunId}'
packages = candidate / 'artifacts/packages-ubuntu-x64'
diagnostics = candidate / 'artifacts/diagnostics-ubuntu-x64/work/ci-artifacts'
infos = {}
for platform in ('windows-x64', 'ubuntu-x64'):
    folder = candidate / 'artifacts' / ('packages-' + platform)
    sums(folder)
    info = json.loads((folder / ('build-info-' + platform + '.json')).read_text('utf-8'))
    assert info['source_commit'] == args.Commit and info['working_tree_dirty'] is False
    assert info['project_version'] == args.Tag.removeprefix('v')
    infos[platform] = info
info = infos['ubuntu-x64']
archive = packages / info['project_source']
with archive.open('rb') as stream:
    source_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
with tempfile.TemporaryDirectory(prefix='qcws source proof ', dir=root / 'work') as temporary:
    target = Path(temporary).resolve()
    with tarfile.open(archive) as bundle:
        for member in bundle.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
            assert member.isfile() or member.isdir()
            assert (target / member.name).resolve().is_relative_to(target)
        bundle.extractall(target, filter='data')
    locks = list(target.rglob('config/dependencies.lock.json'))
    assert len(locks) == 1
    source = locks[0].parent.parent
    files = verify_quality(diagnostics / 'quality/quality.json', source, info, args.Commit,
                           args.RunId, 'xiaobing318/QCopilots-WebSearch', args.Attempt)
    public = json.loads((diagnostics / 'public-search.json').read_text('utf-8'))
    verify_public_queries(public, source / 'tests/data/public_queries.json')
    assert public['minimum_live_evidence_passed'] and public['closure']['completed']
    assert public['runtime'] == info['installed_runtime']
    soak = json.loads((diagnostics / 'soak.json').read_text('utf-8'))
    assert soak['full_acceptance'] and soak['checks_passed'] and soak['seconds_per_phase'] >= 300
    assert soak['runtime'] == info['installed_runtime']
    phases = [{key: phase[key] for key in ('name', 'seconds', 'passed', 'peak_rss_bytes', 'stop')} |
              {'requests': {k: phase['requests'][k] for k in ('attempted', 'successful', 'p95_ms')},
               'health_p95_ms': phase['health']['p95_ms']} for phase in soak['phases']]
    result = {'passed': True, 'source_commit': args.Commit, 'run_id': args.RunId,
              'run_attempt': args.Attempt, 'source_archive_sha256': source_digest,
              'bound_quality_files': len(files), 'public_summary': public['summary'],
              'navigation': public['navigation'], 'public_closure': public['closure'],
              'linux_soak': phases,
              'scope': 'Original package checksums, raw quality evidence, public query/ranking/closure, Linux soak. Not full release approval.'}
(candidate / 'artifact-revalidation.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
