"""Verify all three original package attestations before delivery signoff."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
candidate = root / 'work/release-43805306130'
target = candidate / 'attested-packages'
target.mkdir()
for platform in ('windows-x64', 'ubuntu-x64'):
    for path in (candidate / 'artifacts' / ('packages-' + platform)).iterdir():
        if path.suffix in ('.zip', '.msi', '.deb'):
            shutil.copyfile(path, target / path.name)
env = {**os.environ, 'GCM_INTERACTIVE': 'never', 'GIT_TERMINAL_PROMPT': '0'}
credentials = subprocess.run(['git', 'credential', 'fill'],
    input='protocol=https\nhost=github.com\nusername=xiaobing318\n\n',
    capture_output=True, text=True, check=True, timeout=30, env=env)
os.environ['GH_TOKEN'] = dict(line.split('=', 1) for line in credentials.stdout.splitlines() if '=' in line)['password']
os.environ['PATH'] = str(root / 'work/gh/bin') + os.pathsep + os.environ['PATH']
sys.path.insert(0, r'C:\Dev\github-repos\QCopilots-WebSearch\scripts')
from promote_release import api, verify_attestations
repo = 'xiaobing318/QCopilots-WebSearch'
repository = api('repos/' + repo)
report = verify_attestations(target, repo, repository,
    '3e13f7bd930ffa495e14d50c3556028a21484204', 'v0.1.4', 43805306130, 1)
print(json.dumps({'passed': True, 'report': str(report)}))
