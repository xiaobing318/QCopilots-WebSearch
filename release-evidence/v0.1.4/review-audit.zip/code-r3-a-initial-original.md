R3 Agent A 独立初始审查结果：**暂不能签署最终交付通过；源码总体可行，发现 1 项 P2 测试覆盖退化，未发现可证实的 P0/P1。最终候选验收仍为 pending。**

身份为本次实际 Codex 子代理 `/root/code_review_a_r3`。模型及推理档位：继承、未独立验证。全程只读，没有修改文件、运行测试、启动服务或查看其他席位结果。

输入与覆盖：

- 完整读取任务卡、源码清单及初始证据索引。实际 HEAD 与冻结版本一致：native `3e13f7bd930ffa495e14d50c3556028a21484204`，QGIS `f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d`。
- 两份 patch 的长度、SHA-256，清单内每个源码文件，以及 16 份初始证据的长度和 SHA-256 均匹配。
- 完整审读 native 自有运行时实现、头文件、配置/schema、CMake、httplib 补丁、所有第一方构建/验收/发布脚本、测试程序及文档。重点覆盖 `pipeline.py`（任务卡所称 build_pipeline 实际文件）、quality、soak、安装器、制品 inventory、receipt、attestation、不可变原始证据获取和 promotion。
- 完整阅读 QGIS patch，并补读共用 MCP 分发、schema 验证、security policy、service wrapper、process controller 的相关调用路径与既有七服务启动默认值。
- **覆盖限制**：native 整份 patch 已校验并核对清单，但未逐行审计内嵌第三方 JSON::PP 实现、完整 Python 依赖锁中的每个分发哈希、许可证全文及每个 fuzz corpus 原始字节；未审计下载后第三方库全部源码。大型 QGIS build/publish 和 native validation 日志采用完整性校验与关键阶段/错误/结尾抽查，并非逐行阅读。较小详细测试、receipt、生命周期和五份 WebUI 原始记录已阅读。没有把这些遗漏称为完整逐行审核。

四维评分为本阶段评分，收到最终不可变 addendum 后才能更新：

| 维度 | 分数 | 判断 |
|---|---:|---|
| 需求 | 9.0 | 独立服务、四工具、三接口、五并发、独立健康容量、QGIS 分离边界和范围排除均有对应实现 |
| 技术 | 8.8 | 连接级地址校验、手动重定向、身份隔离、取消与合并请求、缓存事务及制品身份链设计合理 |
| 质量 | 8.0 | 回归覆盖较广，但 stdio 背压夹具已与新 ID 限额失配；最终候选 quality 证据尚未提供 |
| 交付 | 5.8 | 本地构建及发布版集成证据成立，但最终两平台制品和 Windows 11 精确包验收未闭合 |
| **等权均分** | **7.9** | **当前立场：无法完成最终签署** |

**A-R3-01 — P2，已确认的测试覆盖缺口，未确认运行时缺陷**

证据：[test_stdio_transport.py:31](C:/Dev/github-repos/QCopilots-WebSearch/tests/test_stdio_transport.py:31)、[protocol.cpp:117](C:/Dev/github-repos/QCopilots-WebSearch/src/protocol.cpp:117)。

`pressure()` 发送 262144 字符的 ID；现在 `handleRequest()` 对序列化超过 65536 字节的 ID 返回 `id:null` 的短 `-32600` 错误。因此 `close_reader=False` 分支只产生短响应，不能依靠这次发送压满 stdout 管道，却仍报告“non-consuming stdout”成功。`test_process.cpp` 的正常响应读取也不能补足真实不读取管道场景。

影响是：现有 PASS 不能证明 **stdout 真正背压时关闭 stdin 能及时退出**。关闭读端的 broken-pipe 分支仍有价值，不应一并否定。

最小建议：使用合法的接近上限 ID，或足够多个合法大响应，并明确证明输出处于背压状态，再关闭 stdin、验证五秒内正常退出。可先对最终 CI 原始可执行文件补充独立验收，保持冻结源码不变；仓库夹具修正另行记录。如果修改冻结仓库测试文件，须明确触发源码冻结及第三轮上限规则，不能沿用当前输入签署。

验证状态：静态路径已确认；我没有运行补充试验。

**A-R3-Q1 — P2 候选疑问，尚未复现，不计作已确认缺陷**

证据：[quality.py:98](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:98)、[quality.py:105](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:105)、[quality.py:58](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:58)。

质量工具即使已 `wait()` 回收组长，也在 `finally` 无条件按数值 PGID 调用 `killpg`；TERM 后还延迟再次发送 KILL。疑问是：原组消失且数值被复用时，是否存在误伤其他进程组的窗口。它不同于已经修正的 `soak.stop_process()` 已退出句柄检查。

仅凭当前证据不能宣称发生过误杀。建议先用模拟生命周期验证正常退出和 PID/PGID 复用路径；若可触达，再采用能保留所有权的清理方式，同时保留对本任务孤儿子进程的清理。无需凭此疑问立即重构或推翻候选。

已确认的实现与证据：

- R2 的 64KiB 序列化 ID、完整 1MiB 输出预算、超大客户端响应身份检查、失败初始化 session 清理均能从代码和回归定位。
- 构建代理显式覆盖继承代理/bypass/pip 设置；soak 对已回收进程先检查句柄状态；U+FEFF 保留修复覆盖 DOM 片段及 find；SQLite FULL 完整回滚重试、有效 LRU、失败保留 touches 和缩小 maxEntries 使用实际旧数量均有对应实现和测试。
- 180 秒 core watchdog 与逐 suite 刷新进度存在，未通过删除 2000 次压力操作或放松业务截止时间获得通过。
- 本地日志记载 CTest **7/7 通过**、core **3307 assertions / 0 failed suites**；Windows security 内部仍有 **11 passed、1 skipped**，跳过原因是创建 reparse fixture 的 Win32 1314，不能表述为全部安全子用例实测通过。
- QGIS 构建记录为 **46 实际通过、2 个既有 Git 检查跳过**。发布流程较早的 startup probe 曾超时后终止；后续独立 `launch4Release` 生命周期记录正常退出，两者不应混写。
- WebUI 原始记录支持本地 v0.1.3 的四工具闭环、受控搜索结果到真实公网页面读取与 literal find、后端停机仍可发现四工具、`backend_unavailable/retryable=true`、恢复后 `ready/capacity=5`，以及原 MCP 状态恢复。
- 以上 QGIS 证据不是最终 v0.1.4 CI ZIP/MSI 原始字节验收。开发页三次加载失败仍是失败，根因未证实；按用户变更只作为诊断历史保留。

最终签署仍需同一不可变 addendum 提供：

1. CI43805306130 的实际完成结果、同一 attempt 的两平台制品、receipt/inventory/SBOM、校验和及 attestation。
2. Linux quality 原始日志、每项 300 秒 fuzz、冷/热各 300 秒稳定性，以及对应 DEB、Caddy、真实公网查询与清理证据。
3. Windows 11 原始候选 ZIP/MSI 生命周期、升级/回滚、移动路径 SDK、冷/热各 300 秒稳定性，绑定包哈希、runtime、验收脚本及实际 PowerShell 身份。
4. 使用最终候选 runtime 的 `launch4Release` 四工具闭环及环境恢复；建议同时补足上述真实 stdio 背压验收。
5. 最终委员会裁决后，QGIS 提交推送、公开分支/证据发布验证完成，才允许精确字节 promotion。

当前没有证据支持把 v0.1.2 超时归因于某个确定原因，也不能把 v0.1.3 取消或将来的验收当作通过。
