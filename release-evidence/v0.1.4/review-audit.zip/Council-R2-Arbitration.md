# 代码 R2 仲裁

冻结输入为原生 `5dd5fd67e9baea9ea11993ffb75f81cb1d8af1e6` 和 QGIS `52eab8de6674e41537429f0ba22c3b192a744001`。原始报告、任务卡、哈希和执行记录见 [证据目录](evidence/council-r2)。本轮全部原始报告返回后，主代理才修改源码。

| 席位 | 执行身份 | 需求 / 技术 / 质量 / 交付 | 综合 |
| --- | --- | --- | --- |
| A | `/root/code_review_a_r2`，继承模型与推理档位，未独立验证 | 9.0 / 8.6 / 8.2 / 7.8 | 8.4 |
| B | `/root/code_review_b_r2`，继承模型与推理档位，未独立验证 | 8.8 / 8.7 / 8.1 / 8.0 | 8.4 |
| C | Companion `cc-mwio7q4a-8e254865`，会话 `c54ac81a-ab78-43c4-8076-88cfcf81ad47` | 8.5 / 8.0 / 8.0 / 7.0 | 7.9 |

C 的 77 条实际 assistant 记录均是 `claude-opus-5-5` / `xhigh`。原生工具携带的直接差异为 `10bf45b` 到 `5dd5fd6`，完整冻结补丁与 QGIS 输入作为显式补充文件提供。C 原报告披露未覆盖部分构建和测试文件，因此不得将该轮称作完整仓库覆盖或最终一致通过。

| 项目 | 仲裁与修复 | 验证 |
| --- | --- | --- |
| A-01，P2 | 已证实。序列化请求 ID 上限 64 KiB，超限错误明确返回 null ID。限制内保留 ID，完整回复超限转 JSON-RPC 错误。异常初始化清理新会话 | 恰好 1 MiB 输入、不同转义/Unicode ID、HTTP/stdio 后续可用性、大 ID 与大正文组合、完整回复兜底 |
| A-02 / B-02，P2 | 已证实。配置代理覆盖继承路由与绕过列表，下载 handler 不再查询宿主 bypass，pip 不读取宿主配置 | 旧实现 4 个代理子用例失败，修复后 6 项测试通过，无真实外网依赖 |
| A-03，P2 | 已证实。已回收 Popen 在任何 PID 重开之前返回 early_exit | 模拟复用 PID 时禁止构造 psutil 根对象或等待其子进程，旧实现失败 |
| B-01 / C-02，P2/P3 | 已证实。DOM 片段采用保留 U+FEFF 的 UTF-8 解码，文件层 BOM 检测不变 | 字符引用、原始 UTF-8、嵌套 span，首次读取、缓存及查找，旧实现失败 |
| C-01，P2 | 已证实。仅对 SQLITE_FULL 回滚并重开完整事务，先按有效 LRU 释放更多页，再持久化命中顺序。最终失败保留旧数据 | 2000 次小项写入、近满库大量命中、热点保留、缩小 maxEntries、重新打开、原有 BUSY/不可恢复 FULL/trigger-abort 测试 |
| B-03，P3 | 采纳。说明中的 Web Search 默认端口更正为 48218 | 与实际配置逐项核对，纯说明修改 |
| C-03，P3 | 采纳。MSI 报告记录执行脚本哈希、PowerShell 版本和基线来源，发布检查绑定标签脚本、升级标识、较低版本和基线字节 | 新增 7 个篡改/缺失证据子用例在旧验证器失败，新验证器通过。真实最终 MSI 验收待候选产物 |
| C-04，P3 | 采纳。最终 QGIS 提交必须推送供用户获取 | 待最终复审与推送 |
| C-05，P3 | 暂不修改。逐项缩减先移除链接的策略已显式标记截断，输入和结果数量均有界。报告中的性能估计没有实测，尚无超过验收阈值的证据 | 保留实际稳定性门禁，若最终测试显示问题再处理，不增加无依据重构 |

补充仲裁发现并修复了两个实现边界：大 ID 客户端 response 仍需执行会话/身份验证，SQLite 恢复上限应依据旧库的实际候选条数。它们不是新增独立席位或评分。

Windows 最终 `configure,build,test` 退出 0，7/7 CTest 通过，总耗时 23.10 秒。测试 receipt 的源文件哈希与当前字节一致。[旧代码失败日志](evidence/council-r2-regression-before.log)、[修复后日志](evidence/council-r2-regression-after.log)。第一次修复构建暴露了两个 C++ 声明问题，已修复并复测，没有将该失败构建记作通过。

修复提交：原生 `72008a9e75c4591cef23ab688cfee843674a2c34`，QGIS `f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d`。`v0.1.0` 目前仅为验收候选标签，尚未正式发布。后续需完成同一源码和精确包的双平台完整验收，再在最终快照上执行 R3。

交付准备追加发现 B-DELIVERY-01：GitHub Contents API 对超过 1 MB 的文件不再内联 base64，完整稳定性证据会被现有 promotion 拒绝。依据为 [GitHub 官方接口约定](https://docs.github.com/en/rest/repos/contents#get-repository-content) 与已有原始 Windows 报告 3,963,413 字节（压紧 JSON 后仍 2,196,535 字节）。已使用大于 1 MB、包含中文和 CRLF 的控制数据复现，改为同一不可变 commit 上 object 元数据与 raw 字节读取，保留大小与 SHA 检查。33 项发布测试及 Windows 7/7 CTest 均通过。[修复前](evidence/promotion-large-evidence-before.log)、[修复后](evidence/promotion-large-evidence-after.log)。

该修复为 `995745ede4958b45eb64ed4796daa2678fac6eee` / `v0.1.1`。旧 `v0.1.0` 标签未移动或删除，旧 CI 主动取消，不能作为完整通过证据。上述追加核查不增加正式评审轮数或评分。R3 尚未执行。
