# QCopilots 页面加载现场分析

本次开发版 PID 16172 已正常退出。按用户纠正，后续使用指定的 `launch4Release` 阶段，实际启动发布包 `C:/Data/QGISPackages/ff40200qcopilots/QGIS40200-RelWithDebInfo/bin/qgis-qt6-bin.exe`，PID 21100。

发布版在 2026-11-15 20:05:01（本机时间）成功显示页面，日志记录 `QCopilots web view loaded: https://chat.vastarmorai.com/`。两个 QtWebEngine 子进程正常存活，路径均位于发布包 `apps/Qt6/bin`。对应截图为 `evidence/qgis-release-webui-loaded.png`。

开发版三次加载失败。原提示中的 HTTP 200 来自 `qcopilots_container_dock.cpp` 的独立 `QNetworkAccessManager::head()` 探测，不是 Chromium 页面的响应状态。页面侧仅记录 `loadFinished(false)`，没有实际 Chromium 错误码或渲染进程退出码。失败时没有存活的 QtWebEngine 子进程。

开发与发布使用相同字节的 Qt6Core 和 QtWebEngineProcess，分别位于 OSGeo4W 与发布包。两种启动环境和目录布局不同。发布程序旁有 qt.conf，开发程序旁没有。但原 OSGeo4W qtpaths 在无相邻 qt.conf 时仍可正确解析 helper 路径，因此不能将缺少该文件认定为根因。

结论：发布版目前未复现页面加载问题，可以继续发布版验收。开发版具体失败原因未证实，不能声称代码修复了它，也不能将开发版启动和退出成功当作页面验收通过。未为此修改 QGIS 代码或全局网络配置。

## 独立的网页读取网络限制

发布版 MCP 的初始化、工具发现、状态和搜索夹具调用成功。公网正文读取遇到两类不同结果。

- `https://1.1.1.1/cdn-cgi/trace` 两次返回 `provider_unavailable`。独立 curl 直连也出现 TLS 握手失败，属于本机网络现场限制。
- `https://example.com` 返回 `destination_blocked`。系统 DNS 实际返回 `198.18.0.20`，www.baidu.com 返回 `198.18.0.21`，均处于非公网 Fake-IP 网段，服务按既有 SSRF 规则拒绝。

原始 WebUI 失败观察保存在 `evidence/release-webui-first-closure.txt`。未删除失败或降低 SSRF/TLS 校验。已向用户请求是否临时排除 example.com 的 Fake-IP，未取得答复前不修改代理。

## 无需调整代理的验证与清理

进一步只读检查发现现有 Clash 规则已排除 `*.msftconnecttest.com`。该域名解析为公网地址，`http://www.msftconnecttest.com/connecttest.txt` 可直连。通过同一发布版 MCP 实际完成读取与查找，正文为 `Microsoft Connect Test`，page_id 为 `19ed3dcc-1200-40e7-8f85-ae06857921bc`，查找在第 1 行命中。未更改 Clash 配置，也未清空其 DNS 状态。此前的临时调整请求已无执行必要。

后端停机时 WebUI 收到 `backend_unavailable`，四个本地 MCP 工具仍可发现。恢复后 `web_search_status` 返回 `ready`。原始观察与截图分别保存为 `evidence/release-webui-backend-offline.txt`、`evidence/release-mcp-discovery-backend-offline.txt` 和 `evidence/release-webui-recovery-open-find.*`。

本次搜索夹具仍返回 Cloudflare 地址，因此这组记录证明各工具调用及恢复行为，不冒称同一搜索结果 URL 的完整闭环。最终公网搜索闭环另由候选 CI 的真实 SearXNG 验收证明。

发布版已正常退出，pipeline 退出码 0，后端正常停止耗时 0.218 秒，未强制终止任何子进程。隔离 helper 确认原始 QGIS 配置与 profiles 不变。WebUI 临时 MCP 已删除，Vastarmor AI 恢复启用，Browser 与先前创建的 Chrome 测试标签页均关闭。原始 helper 报告保存在 `work/qgis-integration-t5_fr_q6/evidence.json`。

## 当前 v0.1.3 同源复测

2026-11-15 20:30 再次使用原始 launch4Release 命令。QGIS 发布包提交为 `f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d`，原生服务来自提交 `699e2e9431b4e4912436acd38c079c535c3b23e1` 的本地构建安装，7/7 CTest 通过。该结果证明同源联调，不替代最终 CI ZIP/MSI 包验收。

发布版内嵌页面再次正常显示，截图 `evidence/qgis-release-013-loaded.png`。WebUI 连接本地 MCP，协议 2025-06-18，发现四个工具。此次搜索夹具直接返回 `http://www.msftconnecttest.com/connecttest.txt`，随后成功读取同一 URL，使用 page_id `513e3afd-f7de-46fe-9120-a846e63d0e25` 查找 Microsoft，在第 1 行命中。原始展开工具结果为 `evidence/release-013-webui-closure.txt`，截图为同名 jpg。这是受控搜索加真实公网读取闭环，不是上游搜索覆盖率测试。

后端受控停止时，调用返回 `backend_unavailable` 和 `retryable=true`，刷新后仍发现四个工具。恢复后 `web_search_status` 返回 `ready`、capacity 5。原始观察分别为 `evidence/release-013-webui-offline.txt`、`evidence/release-013-webui-offline-discovery.txt`、`evidence/release-013-webui-recovery.txt`。

QGIS PID 21520 已正常退出，pipeline 返回 0。后端停止耗时 0.218 秒，没有强制终止或遗留 QGIS/QtWebEngine/WebSearch 进程。临时 MCP 已删除，Vastarmor AI 恢复原启用状态，Browser 测试页关闭。配置及 profiles 校验不变，见 `work/qgis-integration-5s_52f9i/evidence.json` 和 `evidence/release-013-webui-restored.*`。


## 最终 v0.1.4 原始包验收与白屏复现

本节更新早期“发布版未复现”的观察。2026-11-15 21:21 至21:42（本机时间），按原始 launch4Release 命令启动 QGIS f69eeed 发布包，PID5396。后端使用 CI43805306130 的原始 v0.1.4 ZIP，其 exe SHA256 为 a46e7e39744f5e5a48976ade6c9021dc62649ea2be096570c20856e7e7c7e305，整个运行目录指纹为 e85e40bfd1e8daa8624372c6523343e764f02824b50cdf008f16d9061264ff42。实际 --Version 输出 QCopilots-WebSearch0.1.4、Qt6.12.0。helper 记录的插件源码与发布包逐文件一致。

此轮内嵌页面首轮出现持续白屏，不能再概括为发布版完全未复现。21:21:45.163 容器记录 loadFinished(true)，另行 HEAD 探测200，renderer7592 存活。Qt 元属性显示期望 URL、loading=false、visible=true、有效内容尺寸，内部 QQuickWidget 也可见。这与开发版 loadFinished(false) 且无存活 renderer 的现场不同。父控件 visibleRegion 为空可能由子控件覆盖导致，不能单凭此值确定绘制缺陷。

本机缺少 PyQt6.QtWebEngineWidgets，未安装额外绑定或使用不安全的 C++ ABI 调用获取 DOM。一次上下文菜单 Reload 后，21:32:54.330 日志再次显示加载成功。随后窗口处于最小化状态，用户还原窗口后，21:42:04保存截图时实际看到 WebUI 导航、MCP 入口和输入区域，AX 文档标题为 vastarmor-ai。截图 qgis-release-014-initial-blank.png 与 qgis-release-014-loaded.png、元属性记录及容器日志均保留。

确定结论是“重载及窗口还原后恢复显示”。现有证据不能区分重载、还原触发重绘、前端状态或网络时序的影响，不能认定 UAC、GPU、代理或 qt.conf 为根因，也没有做相应源码修复。最终发布版显示验收通过，但初始加载可靠性仍是已披露的诊断限制。开发版三次失败继续保留为 false，遵循用户明确的仅发布版验收范围。

最终 Browser 联调的四个实际工具结果已展开保存：受控搜索返回微软公开连通性文本 URL，随后真实公网 open 和 find 在同一个 page_id bc40ba25-fe5e-49bc-8e8e-378454720599 第1行命中 Microsoft。后端停止时错误为 backend_unavailable/retryable=true，四个工具仍可发现，恢复后 ready/capacity5。此处搜索是受控夹具，真实 SearXNG 60条公网查询的证据另见候选 CI，不混为一项。

临时 MCP 已移除，Vastarmor AI 恢复原启用状态，本轮 IAB 测试页关闭。QGIS 正常关闭、pipeline退出0，后端最终正常停止0.22秒，没有强制终止或遗留本轮进程。配置及原 profiles 指纹不变，Clash未修改。最终原始记录为 work/qgis-integration-8wkraorw/evidence.json 和 evidence/release-014-webui-*。安装包流程之前的15秒自动启动探针被强制终止是另一轮历史记录，不改写为正常关闭。
