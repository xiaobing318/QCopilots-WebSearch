B 席独立 R3 初始结论：**当前无法最终签署通过**。冻结源码中未发现已证实 P0/P1；发现一项 P3 测试覆盖退化。最终候选 CI、Windows 11 精确包验收和最终包 QGIS 闭环仍为 pending，不能以本地成功或旧版本联调替代。

身份：真实子代理 `/root/code_review_b_r3`，重点正确性、质量、构建测试和交付；模型及推理档位**继承、未独立验证**。本轮只读，没有修改文件、启动测试/服务、Git 变更或读取其他席位结果；未读取被排除的 AGENTS.md、`.codex`、凭据或用户配置。

| 维度 | 当前评分 |
|---|---:|
| 需求符合度 | 9.0 |
| 技术正确性 | 8.8 |
| 质量与测试 | 8.4 |
| 交付与可复现性 | 6.0 |
| 四维等权均分 | **8.1** |

交付分反映必要证据尚缺，并非已经证明候选包失败。整体立场为 **unable / 等待同一不可变最终证据 addendum**，不是条件通过。

**冻结身份及实际覆盖**

已完整读取任务卡、源码清单和初始证据索引，按 Council v2 rubric 审查。直接读取两仓 HEAD，均匹配：

- native：`3e13f7bd930ffa495e14d50c3556028a21484204`
- QGIS：`f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d`

已逐项计算清单中所有变更文件、两个 patch 及初始证据文件的大小/哈希，全部匹配。哈希一致只证明输入身份，不等于逐行审查。

实际内容审查覆盖：

- native 全部运行时 `.cpp`：main、config、network、html、cache、service、protocol、server、stdio_output、windows；common/protocol/service 头文件及 stdio_output 头文件。
- CMake 主文件、Dependencies、Install、Licenses、Packaging、httplib 补丁。
- 完整 `scripts/pipeline.py`、PowerShell/Bash 入口及 bootstrap 配置读取器、Windows CI 工具准备；任务卡所称 `build_pipeline.py` 在仓库中对应实际文件 `scripts/pipeline.py`。
- 完整 quality/quality_evidence、soak、process_cleanup、build/runtime/public evidence、package/MSI inventory、release_assets、verify_release、promote_release、两项工作流。
- Windows ZIP/MSI、DEB、Caddy 验收脚本，live_acceptance、run_live_compose、MCP SDK 测试，Debian 服务生命周期和 MSI 服务补丁。
- 完整 pipeline、release acceptance/assets/navigation、HTTP limits、process、stdio transport、Windows security、TLS fixture 测试，fuzz harness、Ubuntu bootstrap 测试；core 测试重点覆盖协议大小/ID/会话、SQLite BUSY/abort/FULL/LRU/缩容、全部 2000 次写入及进度输出。
- QGIS **完整变更 patch**；适配器、配置、四工具契约、发现/库存/适配器测试；必要公共上下文包括 ServicePlugin、formal_restricted 路径/网络校验、默认启动列表以及 MCP lifecycle/schema/tool dispatch。

必须披露的遗漏：

- **1,039,272 字节 native 完整 patch 未从头至尾逐字通读**；采用冻结文件直接读取完成上述重点覆盖，不能声称满足“完整 native 全补丁逐行审查”。
- native 剩余若干短声明头、部分 core 非重点测试、`tests/release_quality_fixture.py` 未完整检查；config schemas、依赖锁及 Python 锁、完整 fuzz 种子/公开查询数据、部分 README/设计研究/API/部署文档、团队部署模板未逐项全文审查。
- vendored Perl 实现和第三方许可证正文未做语义审计；Licenses/Packaging 的收集分发逻辑已经检查。
- QGIS 公共模块只检查相关上下文，未审查其余历史实现；大型构建/发布日志按阶段、错误、测试与完成记录检查，未逐字阅读全文；UI 文本证据检查了关键工具与状态，未独立操作 UI 或重验截图。
- 本次没有独立运行任何测试；下面全部是对冻结记录的核对。

**问题**

**B-R3-01 · P3 · 已证实测试覆盖退化，未证实运行时故障**

位置：[test_stdio_transport.py:31](C:/Dev/github-repos/QCopilots-WebSearch/tests/test_stdio_transport.py:31)、[protocol.cpp:117](C:/Dev/github-repos/QCopilots-WebSearch/src/protocol.cpp:117)。

触发：`pressure(..., close_reader=False)` 不读取 stdout，却只发送一个含 262144 字符 ID 的 ping。新协议将 serialized ID 超过 65536 字节的请求转换为 `id:null` 的小型 `-32600` 错误，因此此输入不再产生原先的大量 stdout 数据。

影响：用例通过可以证明小响应后的 EOF 退出，**不能证明输出管道实际满载时能够取消阻塞写入**。`test_process.cpp` 逐条接收回复，也没有补上此条件。closed-reader 分支仍可验证断开读端。运行时 [stdio_output.cpp:121](C:/Dev/github-repos/QCopilots-WebSearch/src/stdio_output.cpp:121) 有 250ms flush、abort、Windows 重复取消和 POSIX 非阻塞轮询逻辑；本席未发现它的已证实故障。

最小建议：使用合法 ID 形成超过平台管道容量的未读响应，确认输出确实停滞后再 EOF；保留关闭读端分支。当前冻结规则下，也可提供对**同一候选字节**的独立不可变外部验收，且必须证明真正背压已形成，不能仅复用此用例的 PASS 文本。

验证：Windows 和 Linux 均需证明超过管道缓冲的数据未被读取、进程在限时内退出、无遗留线程/进程；区分正常 EOF 与断读端退出码。此项是非阻断 P3；不能把既有 7/7 当作真实背压已验证的证据。若修改仓库测试文件，应明确触发冻结输入变化及第三轮上限处理，不能静默替换本轮源码。

**B-R3-Q1 · P3 调查问题 · 静态疑点，非确认缺陷**

位置：[quality.py:98](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:98)、[quality.py:105](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:105)、[quality.py:58](C:/Dev/github-repos/QCopilots-WebSearch/scripts/quality.py:58)。

`run()` 正常 `wait()` 回收子进程后，finally 仍先以数值 PID 调用 `killpg`，然后才 poll；TERM/KILL 之间又有等待。与 soak 对已回收进程的修复不同，质量工具仍依赖数值 PGID。需要确认在共享、高进程周转执行环境下，是否可能对已复用的组号发送信号。

只有静态路径，没有复现或初始日志异常；不据此宣称误杀已发生，也不要求本轮为推测重构。Linux 的组信号按数值组号选择目标，而 wait 会释放终止子进程资源，语义见 [kill(2)](https://man7.org/linux/man-pages/man2/kill.2.html) 与 [wait(2)](https://man7.org/linux/man-pages/man2/wait.2.html)。建议确认托管隔离假设，或以模拟复用/身份保留测试关闭该疑问；保留对原有残留子进程的清理能力。

**独立核查所得**

- 1MiB 完整 JSON-RPC envelope 与 64KiB serialized ID 限额一致；过大 client response 仍执行会话/身份校验；过大初始化响应删除新建会话；边界、转义字符、Unicode、跨身份响应测试存在。
- UTF-8 decoder 在 DOM fragment 与 find pattern 使用显式 BOM 保留；SQLite FULL 的 rollback、完整事务重试、有效 LRU、pending touches 保留和实际旧条目计数，与重点测试对应。
- 显式代理覆盖继承 bypass/pip 配置；soak 在重开 PID 前检查已回收 Popen；核心 watchdog 为 180s，进度刷新，2000 次压力写入和 3307 条断言未删。
- MSI evidence 绑定验收脚本、baseline 字节/source/upgrade identity、PowerShell identity；推广下载完整不可变 raw bytes 后检查 size/digest，支持大于 1MiB 证据。
- receipt → runtime inventory → ZIP/MSI/DEB → CI identity/attestation → draft 下载复核的绑定链存在；推广路径不重新构建。
- QGIS 保留原 formal_restricted 与启动默认列表；backend/MCP token 分离；业务 5/status 1 独立限额；没有接管 native 生命周期。文档端口为 48218。最终 QGIS gate 按用户最新要求为 launch4Release。

**实际观察到的测试及限制**

冻结证据目录为  
`C:/Users/xiaob/Documents/Codex/2026-11-14/qgis-c-dev-github-repos-qgis-8/work/council/r3-initial-evidence/`。

- `native-014-core-detail.log`：7/7 CTest；core 3307 assertions、0 failures，26.74s，cache_pressure 约22.77s；release regression 33 项通过；pipeline 6 项通过；HTTP/TLS/stdio 测试通过。
- Windows 文件安全测试为 **11 passed、1 skipped**；reparse fixture 因 Win32=1314 权限不足跳过，不能写成全覆盖通过。
- `release-only-before.log` 保留旧 verifier 要求 development gate 导致的失败；`release-only-after.log` 为 33 项通过。
- `qgis-f69-build.log`：46 项通过，2 项既有 Git 检查跳过；48 selected、0 failed。
- `qgis-f69-publish.log`：manifest 检查及发布完成；其自动 startup detection 在关闭等待 15s 后强制终止进程。这与随后指定 launch4Release 验收是不同运行，不能混写成全部正常退出。
- `qgis-release-013-lifecycle.json`：随后 launch4Release 联调正常退出，四工具、受控搜索→真实公开文本读取→literal find、离线发现和恢复、配置/用户状态还原均记录成功，native stop 约0.218s、无强杀。但使用的是本地 v0.1.3 runtime，**不是最终 v0.1.4 CI ZIP/MSI 字节验收**。
- development 页面三次加载失败仍未解决；诊断未证明根因。按用户调整不再作为最终 gate，但不能称其通过。
- v0.1.2 的旧 60s core timeout 和 v0.1.3 取消，不是本候选成功证据；托管超时根因未证明。

最终签署前仍需同一不可变 addendum 提供并核对：候选 run43805306130 全部必要 job 结果、最终制品/源码/运行时绑定、Ubuntu 与 Windows 平台验收、Windows 11 精确 ZIP/MSI 安装升级回滚和保留配置、冷/热**每阶段300s**的完整原始样本及原有阈值、各 fuzz300s、最终候选包 launch4Release 工具/离线恢复/退出闭环。QGIS commit push、公开分支和 evidence publication 还需在 Release promotion 前验证。

当前没有证据允许提前通过；收到统一 addendum 后可在源码不变的同一 R3 内完成证据签署。
