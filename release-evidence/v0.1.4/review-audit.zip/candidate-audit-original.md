Message Type: FINAL_ANSWER
Task name: /root
Sender: /root/resume_fix_verification
Payload:
证据绑定一致：**v0.1.4 / `3e13f7bd930ffa495e14d50c3556028a21484204` / run `43805306130` / attempt 1**。已复算匹配四份原始 artifact archive、三份发行包、两份 JUnit、源归档及公网脚本/查询集/compose SHA；quality 的 **41 个绑定文件及 quality.json，共 42 项**也匹配。[复验记录](C:/Users/xiaob/Documents/Codex/2026-11-14/qgis-c-dev-github-repos-qgis-8/work/release-43805306130/artifact-revalidation.json)

- 发布构建 CTest：Ubuntu **6/6**，Windows **7/7**。
- ASan/UBSan quality：**9/9**，总计 **10.57s**；core **14 suites、3307 assertions、0 失败，7.69028s**；build-pipeline 内部 **6 tests**，release-assets **33 tests**；clang-tidy **16/16 translation units**。
- **cache-physical-pressure 未超过 90s**：ASan **5.25824s**；Windows 发布版 **80.3278s**，Windows core 总计 **88.8656s**。
- 未见 sanitizer 错误标记；覆盖不包含预编译 Qt/ICU 和系统 OpenSSL。

ASan core 各 suite 秒数：

```text
network                  0.0257354   network-regression      0.486375
coalescing               0.103628    cache                   0.285591
cache-failures           0.769399    cache-physical-pressure 5.25824
html                     0.010595    html-boundaries         0.195815
service                  0.0285336   unicode-page            0.0407666
concurrency              0.0239206   protocol                0.167723
json-and-deadlines       0.0266556   http                    0.141697
```

三类 fuzz 均配置 **300s**，原始 DONE 均为 **301s**：

| Fuzzer | Executed units | 最终 cov |
|---|---:|---:|
| HTML | 52,118 | 1,841 |
| URL | 2,227,445 | 167 |
| JSON-RPC | 5,861,485 | 1,195 |

`cov` 是 libFuzzer 计数，不是覆盖率百分比；对应原始日志 SHA 已逐一匹配。

清理与公网限制：

- **DEB**：8 项验收完成；停止 **0.04091s**。原始日志确认 purge 后 `MainPID=0`、服务不存在。回滚实际是**注入 postinst 失败后重新安装原基线**；token、缓存及 sentinel 按设计保留，不能表述为“所有数据已清空”。
- **Caddy**：真实 HTTPS/HTTP1、合成 provider；取消恢复 **50.76ms**，native 停止 **0.066s**、未强杀。runner 在写入清理成功前检查项目容器和卷为空；fixture 线程退出。未覆盖公网 ACME、HTTP2 reset、HTTP3。
- **公网**：60 次全部 `partial`，59 次非空，服务错误 **0**；p50 **553.013ms**、p95 **654.753ms**。Google 涉及 **60/60** 查询，SearXNG 明确记录 `AccessDenied`；DuckDuckGo 涉及 **11/60** 查询并记录 `Captcha`。分页累计 failure 条目分别为 **65、16**。
- 唯一零结果为 **en-20**：`World Meteorological Organization State of the Global Climate report release`，`time_range=year`；属于上游受限下的空结果，非请求异常。
- **真实 read/find 闭环**：zh-01 搜索所得 QGIS 投影文档，首次 open 非缓存，find 验证同一 page_id、同一文本字面量与**第 3 行**；记录 literal SHA `8dbf35488c3f264413696c17b7f55650ddefe9d9fc5864ecc85bf7a90075b309`。原始全文未保存，闭环由绑定脚本的契约断言和结果记录支撑。
- 导航 8 例均 top1，MRR@5 **1.0**；无域名过滤、无排名质量阈值，不能外推为整体相关性保证。

严格只读，未运行服务、测试或写入文件。