# Evidence narration clarifications

No source or frozen evidence file was changed. The R3 addendum's two approximate statements are clarified against its own indexed raw evidence:

- The initial local Windows security run had 11 passes and one Win32=1314 reparse-fixture skip. Final CI43805306130 diagnostics-windows-x64/build/ci/Testing/Temporary/LastTest.log line198 and test-results.xml line119 say `Windows security tests: passed=12 skipped=0`. These are different runs.
- The visible final embedded QGIS screenshot and AX were saved at21:42:04 local time. The launch log records PID5396 exiting normally at21:42:22.219. The addendum's approximate `~21:43` is inaccurate. The supported sequence is Reload, minimize, user restoration, visible page observation, then normal close. Recovery and root-cause limitations are unchanged.

Original evidence will be published as a binary ZIP using the existing repository binary rule, preserving all125 evidence files and their original CRLF where present. The original pending-council envelope stays unchanged in the audit. The actual post-vote release envelope will be a new UTF-8 LF JSON. Its digest will be computed from committed Git bytes and compared against immutable GitHub raw bytes before dispatch. This avoids changing frozen attributes or normalizing original reports.

The native repository will not receive the GPL QGIS source patch. Its local frozen patch/hash remain in the private task audit, and the public evidence points to the exact separate GPL QGIS commit. No code licensing boundary changes.

- Supplementary Ubuntu backpressure binding and ldd output are indexed, but the full supplementary job log is not. The previous phrase "binding and logs" was imprecise. After final review, GitHub artifact14199194714 was independently downloaded through the connector and its ZIP SHA256 verified as fcf6f01ca68c1747f09a5cdc6655068909db538b066ec20d462a50ee7f08f01e. This new receipt is supplementary evidence and does not overwrite the frozen index.
- At21:30:52 the container logged a canceled download. Main had attempted page-source/save menu diagnostics and canceled out without a saved output file. The generic log says "user" and does not identify the actual actor or prove a cause of the blank page. The event is retained, not omitted as an error-free session.
- Windows soak overlapped QGIS/IAB testing, and MSI testing overlapped the still-open QGIS session and resumed backend. The metrics satisfied thresholds under these concurrent activities. They are not isolated idle-host benchmark results. Whether this contributed to initial blank rendering is unproven.
- The installed QGIS plugin files match the clean f69 checkout bytes. Some have CRLF where Git blobs use LF, so this is not a claim that installed bytes equal LF Git blob bytes.
- MSI failure-injection logs contain three occurrences of `Error in rollback skipped. Return: 5`. Subsequent explicit service/version/config/ACL/file state checks passed. The engine warning's root cause is not established, and the reports do not claim zero log errors.
