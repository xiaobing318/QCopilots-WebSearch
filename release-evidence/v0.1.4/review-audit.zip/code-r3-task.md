# QCWS code and delivery council R3

Review ID: QCWS-CODE-DELIVERY-R3. Third and final complete code review round.
Read-only independent seats. Main is the sole writer. Do not inspect other
reviewers' reports, messages, tasks, or transcripts before independent results.

## Immutable source scope

Task workspace: C:/Users/xiaob/Documents/Codex/2026-11-14/qgis-c-dev-github-repos-qgis-8
Read work/council/code-r3-sources.json. It fixes both clean repository states,
full patch hashes and every changed file hash. Read the two full patches and
source context needed to examine the implementation, not only recent diffs.

- Native C:/Dev/github-repos/QCopilots-WebSearch: empty base
  c3025b061a0ec1e3343301e6c07cbe9e81861e14 through
  3e13f7bd930ffa495e14d50c3556028a21484204, candidate v0.1.4.
- QGIS C:/Dev/github-repos/QGIS: base
  84b72dce7a3a66f6b9ac968ce60460d6b498b892 through
  f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d.
- Claude transport uses the actual 72008a9..HEAD diff to fit Windows argument
  limits. The complete 1,039,272-byte native patch and 75,564-byte QGIS patch
  are explicitly supplied supplementary files, not claimed to be the tool diff.
  Disclose any paths not inspected. Do not silently call a partial review full.

Excluded: QGIS/QGIS-Materials AGENTS.md and .codex, ignored local configuration,
credentials, user profiles, unrelated historical QGIS. Never read those files.
No edits, Git mutations, installations, test processes or services by reviewers.
Public first-party source and named nonsecret evidence may be sent to Claude
under the user's explicit three-seat review request.

## Accepted requirements and latest user changes

Independent Apache-2.0 C++20/Qt6.12 service and GPL QGIS adapter. Windows11 amd64
and Ubuntu26.04 amd64. Team size 10-50, default five business requests, immediate
capacity rejection and separately responsive health. SearXNG JSON search,
HTML/text open, literal find and status. REST/MCP HTTP/stdio same contracts,
MCP2025-06-18. Token identity page isolation, exact Origin/Host policy, DNS/IP
pinning at each redirect, reject nonpublic destinations, both compressed and
decompressed 5MiB limits, request deadlines and bounded SQLite cache thread.
No PDF, JS execution, paid backend, autonomous indexing or LLM answers. Public
search is best effort, but service errors must remain distinguishable.

Cross-platform configurable bootstrap/build/test/install/publish, detailed
schemas, pinned dependencies and source/license/SBOM/checksum distribution.
ZIP/MSI/DEB with services, configuration preservation, rollback and exact-byte
promotion only after both platforms and Windows11 desktop acceptance.
QGIS retains formal_restricted and existing startup defaults, uses separate
backend/MCP tokens and never manages native backend lifecycle.

User explicitly changed cold/hot stability to 300 seconds per phase. All other
success, p95, memory, health and shutdown thresholds remain unchanged. Fuzz
campaigns remain 300 seconds each. Do not demand obsolete 1800-second soaks.
User explicitly changed final QGIS acceptance to launch4Release only and asked
that development-page failures remain documented. Do not reinterpret failed
development loading as a pass. Published-package testing is the release gate.

## R2 fixes and additions to examine independently

Do not read peer scores. Verify actual code and tests for:
- Full 1MiB JSON-RPC output and 64KiB serialized-ID bound, consistent HTTP/stdio
  fallback, authenticated session checks for oversized client responses, and
  cleanup on failed initialization.
- Explicit build proxy overrides inherited route/bypass/pip configuration.
- Reaped subprocess handles are checked before reopening any possibly reused PID.
- UTF-8 decoding preserves initial U+FEFF in each DOM fragment and find pattern.
- SQLITE_FULL rolls back and retries a complete bounded transaction, evicts by
  effective LRU, preserves pending touches on failure, and counts actual old
  entries when maxEntries shrinks. Existing BUSY/trigger abort behavior remains.
- MSI evidence binds acceptance script hash, baseline bytes/source/upgrade
  identity and PowerShell execution identity. QGIS port prose matches 48218.
- Complete large evidence is fetched as immutable raw GitHub bytes with size
  and digest verification. Do not trim original raw soak samples to fit 1MB.
- Source/runtime receipts, cross-platform inventories and attestations bind
  the exact accepted artifacts. Inspect build_pipeline.py, quality tooling,
  soak.py, promote_release.py, verify_release.py, CI/release workflows, QGIS
  common integration and tests. These are mandatory coverage areas because
  prior review transport did not demonstrate complete inspection of them.
- Core CTest watchdog is 180s with flushed per-suite progress. All 2000 cache
  pressure operations, 3307 assertions and business deadlines are retained.

## Evidence at initial source freeze

The immutable initial evidence index is work/council/code-r3-evidence-initial.json.
Read exact copied logs/reports from that index. Old outputs/Implementation-Status
and old council reports are historical and not this candidate's acceptance.

Local clean v0.1.4 configure/build/test/install completed with 7/7 CTest passing.
The release-only regression failed on the old verifier, then 33 release tests
passed. QGIS f69 exact user configure/build/test completed (46 passed, two
existing Git checks skipped) and install/publish completed with manifest checks.
No clean stage was used. Published QGIS page and all four tools, controlled
search -> real public read -> literal find, offline discovery and recovery
passed with local v0.1.3 runtime. This is same-runtime-code integration, not
proof of the final CI ZIP/MSI bytes. Dev loading failed three times and remains
an unresolved diagnostic outside the user-adjusted final release gate.
All those UI-owned processes, temporary MCP and test tabs were cleaned, original
Vastarmor state, QGIS profiles and pipeline configuration restored.

Current v0.1.4 CI43805306130 is running. Final artifacts, Windows11 exact-package
MSI/ZIP/300s-per-phase acceptance and final package QGIS closure are pending at
this initial review. Do not infer a pass. Source is frozen while these run.
Tag v0.1.2 Windows core hit its old60s watchdog, other six tests passed. v0.1.3
was canceled for the newly authorized QGIS gate change. Neither is a passed
candidate. The underlying hosted timeout cause is not proven.

This R3 begins with independent source inspection in parallel with CI. Return
an honest current assessment, including pending delivery gates. After all three
independent reports, Main will provide the same immutable final evidence addendum
to all seats for R3 final signoff on the unchanged source. That is an evidence
completion within this round, not permission to assume future tests succeed.
If any source must change, flag the frozen-input rule and round limit explicitly.
QGIS commit push and public branch/evidence publication occur after final review
and must be verified before Release promotion. They are not yet completed.

## Required output

State real identity/model/effort only where independently confirmed, otherwise
inherited/unverified. State actual coverage and every material omitted area.
For each issue: ID, P0-P3, evidence status, absolute file:line, trigger, impact,
minimal recommendation and verification. No evidence means a question, not a
confirmed bug. Empty findings are allowed. Avoid speculative redesign.
Give requirement/technical/quality/delivery scores 0-10 or N/A, equal-weight
one-decimal aggregate, and pass/conditional/fail/unable stance. Cite tests
actually observed, do not claim to have run tests. Include remaining evidence.
Use C:/Data/garbage-data/Council/Multi-AgentReviewCouncil.md v2 rubric.
