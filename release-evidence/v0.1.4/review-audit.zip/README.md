# v0.1.4 acceptance evidence

Candidate source: 3e13f7bd930ffa495e14d50c3556028a21484204, tag v0.1.4, CI43805306130 attempt1.
QGIS adapter source: https://github.com/xiaobing318/QGIS/commit/f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d

The original review index uses task-workspace-relative paths. Map work/council/r3-final-evidence/ to this directory's final-evidence/. Other original absolute paths record test identity, not required installation paths. Source and native patch manifests identify the frozen inputs. The GPL QGIS patch is retained in the private task audit only, its code remains in the separate GPL repository linked above.

Original logs and reports preserve their original bytes. Do not normalize line endings before checking the index hashes. The pending-council envelope is the actual pre-vote input, not the final release disposition. Final Windows release evidence and actual council reports are stored alongside this audit after review completes.

The embedded page initially remained blank and recovered after Reload and window restoration. This is not a root-cause fix. See the diagnostic record and original screenshots. Public SearXNG queries are best effort: all60 were partial,59 nonempty,0 service errors, with upstream AccessDenied/Captcha explicitly recorded. Repository stdio backpressure fixture debt remains, with supplementary real full-pipe tests on both final original packages.

This directory contains public review and acceptance material only. Isolated client secrets and browser profile storage are excluded. Reviewer coverage limitations and historical failures remain explicit.
