**A 席原始报告 — QCWS-CODE-DELIVERY-R2-20261115**

结论：**工程阶段有条件通过，可以继续准备标签候选验收；不批准最终交付。** 本席确认两个 P2 缺陷，另保留一个 P2 待验证清理风险；未发现已证实 P0/P1。建议先处理下述问题，再冻结正式验收候选。

**身份与独立性**

我是原生 Codex 子代理 `/root/code_review_a_r2`。具体部署模型版本与推理档位继承会话，未独立核实，不声称已使用最高档位。

使用了三个本席内部只读助手：

- `/root/code_review_a_r2/native_io_readonly`
- `/root/code_review_a_r2/release_readonly`
- `/root/code_review_a_r2/acceptance_paths_readonly`

它们不是额外投票席位。未查阅其他席位或前轮代码评审报告、消息、转录或 `list_agents`，未读取禁读的 AGENTS.md、`.codex`、凭据或忽略的本地配置。

**冻结输入与覆盖**

已读取委员会协议、任务卡和快照，并核对：

- 任务卡 SHA256：`a257ff1e7bc77b105fab5477308da816ea9e9a068b91dd6d5835bef5fcb8d4f5`
- Native HEAD：`5dd5fd67e9baea9ea11993ffb75f81cb1d8af1e6`
- QGIS HEAD：`52eab8de6674e41537429f0ba22c3b192a744001`
- Native patch SHA256：`32f73a1b0f9dd279241d790f939d7e895f889ec769efd35611b031b5629f9d5f`
- QGIS patch SHA256：`c513aa95afe22bcbfe468ec54119ffca02a21805522c516ed279f2496253c003`

开始与结束检查时，两仓库均干净。

审查范围是两个完整冻结补丁所列文件集合，并非仅 `10bf45b..5dd5fd6` 小范围差异。实际深入覆盖：

- 原生配置、缓存、搜索合并、网页提取、分页/查找、身份隔离及生命周期。
- 实际连接地址过滤、逐跳重定向、TLS、传输限额、HTTP/MCP/stdio、取消与输出背压。
- QGIS 全部新增 Python 实现、契约及对应测试；沿既有 MCP、网络策略、服务包装和 Manager 默认启动列表核查。
- 构建/bootstrap、包安装与升级、证据生产及验证、发布推广门禁、运行时与许可证交付路径。
- 相关单元、进程、协议、发布及验收脚本，以及指定的现有验收证据。

边界：未对第三方 vendored Perl JSON parser、每个锁文件哈希和每个 fuzz corpus 字节进行完整语义审计；未逐份检查全部历史原始日志。未运行构建、测试、服务、安装或 Git 写操作。读取补丁与源码不能替代动态验收。

**评分**

| 维度 | 分数 | 依据 |
|---|---:|---|
| 需求可行性 | 9.0 | 能力、排除范围、身份边界及可测标准清晰；公开搜索限制表达准确 |
| 技术可行性 | 8.6 | 原生服务与 GPL 适配器分离合理；网络、缓存和生命周期机制成立 |
| 质量可行性 | 8.2 | 主要边界有实现与回归支持，但仍有响应预算缺口 |
| 交付可行性 | 7.8 | 发布证据链较完整；代理配置存在偏差，最终标签验收尚未完成 |
| **等权平均** | **8.4** | `(9.0 + 8.6 + 8.2 + 7.8) / 4` |

**A-01 — P2，静态确证：大 JSON-RPC ID 可使合法输入生成超预算回复**

- **位置**：[protocol.cpp:148](C:/Dev/github-repos/QCopilots-WebSearch/src/protocol.cpp:148)，下游 [server.cpp:23](C:/Dev/github-repos/QCopilots-WebSearch/src/server.cpp:23)、[stdio_output.cpp:44](C:/Dev/github-repos/QCopilots-WebSearch/src/stdio_output.cpp:44)。
- **触发**：`initialize` 使用由 1,048,429 个 ASCII `a` 组成的 string ID，其他字段为最小合法值：

  ```json
  {"jsonrpc":"2.0","id":"<1048429个a>","method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"a","version":"a"}}}
  ```

- **证据**：固定请求部分为 147 字节，总输入恰为 **1,048,576 字节**，可通过入站限制。`idKey` 为 **1,048,433 字节**，也通过当前 ID 限制。当前版本 `0.1.0` 的初始化回复固定部分为 157 字节，完整回复为 **1,048,586 字节**，超限 10 字节。大小计算已实际执行；没有启动服务动态复现。
- **因果与影响**：HTTP 的 `sendJson()` 把回复替换为 HTTP 500 普通 REST 错误对象，缺少 JSON-RPC 的 `jsonrpc` 和 `id`，既有 error handler 不会修正。stdio writer 将超限消息标记失败并中止，随后进程返回 1；客户端无法继续该 stdio 会话。大 ID 与工具列表或业务结果叠加也存在同根问题。这不是已证实的跨用户拒绝服务或内存越界。
- **最小修正**：在协议层统一预算已序列化 ID、完整 envelope 和结果；在创建会话或执行业务前限制 ID，保证拒绝回复本身仍有界且保持 JSON-RPC 形状。
- **验证**：覆盖恰好 1 MiB 初始化输入、ID 上限两侧、大 ID 加大结果。HTTP 应返回有界协议回复；stdio 拒绝后应仍可处理正常初始化和 ping。
- **置信度**：高，静态因果链完整；动态复现未运行。

**A-02 — P2，已证实配置行为偏差：构建下载代理仍受宿主环境覆盖**

- **位置**：[pipeline.py:49](C:/Dev/github-repos/QCopilots-WebSearch/scripts/pipeline.py:49)、[pipeline.py:103](C:/Dev/github-repos/QCopilots-WebSearch/scripts/pipeline.py:103)，以及 `download()` 中显式 `ProxyHandler` 路径。
- **触发**：在线 bootstrap，配置 `proxy=""` 而宿主存在 `ALL_PROXY/all_proxy`；或配置非空代理而宿主存在 `NO_PROXY/no_proxy=*`。
- **证据**：初始化复制全部环境，仅覆盖四个 HTTP(S) proxy 变量；`pip download` 继承剩余变量。本席助手通过无网络、无安装的合成环境验证，本机 pip 26.1.2 的 Requests 会话在第一种情形选取 ALL_PROXY，在第二种情形不选代理。另已检查本机 `urllib.request.ProxyHandler.proxy_open()`：即使指定显式代理，仍执行 `proxy_bypass(req.host)`；合成 `NO_PROXY=*` 能绕过 `download()` 的非空代理。此行为也符合 [Requests 官方代理说明](https://requests.readthedocs.io/en/latest/user/advanced/#proxies)。
- **影响**：schema 承诺的“空值直连、指定值用于依赖下载”不成立，可能走错误代理、绕过必需代理或导致 bootstrap 失败。依赖哈希校验仍存在，未发现由此绕过完整性校验。
- **最小修正**：统一处理 subprocess 与当前进程 urllib 的代理选择和旁路变量，并明确配置值相对 pip 其他代理来源的优先级。只清理 `self.env` 不能完整修复当前进程 urllib 路径。
- **验证**：用合成环境检查空配置加 ALL_PROXY、非空配置加 NO_PROXY、普通空环境；分别覆盖 wheel 和固定归档下载，保留已有 APT 回归。
- **置信度**：高。代理选择已用纯函数行为验证，未进行端到端联网复现。

**A-03 — P2，待验证风险：Linux 已回收进程的 PID 可在清理前失去归属**

- **位置**：[soak.py:179](C:/Dev/github-repos/QCopilots-WebSearch/scripts/soak.py:179)，关联第 183、206–210、258、268 行；另一路调用在 `live_acceptance.py:196`、`:264`。
- **触发**：Linux 启动失败，启动循环的 `proc.poll()` 已回收原子进程；随后发生调度切换和 PID 复用，替代进程具有子进程。
- **证据**：`stop_process()` 先根据数字 PID 新建 psutil 对象并枚举 children，再检查原 Popen 是否已退出。即使随后记为 `early_exit`，`finally` 仍对刚取得的 children 执行 `kill()`。`wait_owned()` 只能保持已取得对象的身份，不能证明其原始归属。
- **影响**：在这个窄竞争窗口内，清理可能终止无关进程，违反只清理本次工作所拥有进程的约束。
- **限定**：未复现实际 PID 竞争；不主张 Windows 保留原进程 handle 时也成立，也不主张尚未回收的 Linux zombie 可复用 PID。
- **最小修正**：在重新按 PID 枚举 children 前检查原 Popen；已退出则报告失败并跳过枚举。可在启动时保留根进程身份进一步约束清理。
- **验证**：模拟已回收的 Popen 与同数字 PID 的替代进程，断言不枚举、不终止替代进程的 children，无需真实杀进程。
- **置信度**：中高；静态路径明确，发生条件与实际影响尚待验证。请主席单独仲裁，不把它描述为已经发生的误杀。

**证据判断与剩余门禁**

- 已读 BOM 修复前失败与修复后日志，确认修复后 Windows CTest 7/7；对应源码断言覆盖首次 open、缓存再读、含 U+FEFF 的字面查找。
- 指定 MSI 结果确实记录 `Passed=true`、空 `CleanupErrors`、Windows build 26200/product type 1、停止约 0.263 秒；它绑定 `10bf` 候选 MSI，不能认证未来标签包。
- 指定 ZIP 结果记录迁移路径、系统 PATH、HTTP/stdio SDK 及清理成功，同样属于旧候选。
- QGIS 证据中 release 阶段 `passed=true`；development 阶段四工具功能记录成功，但原辅助程序 `passed=false`，随后以单独恢复记录确认退出和恢复。应准确表述为“功能闭环成功，清理经补充恢复验证”，不能把原 development 辅助程序改称全程通过。
- 已核对公开查询报告中的 60 次、57 次非空、全部 partial、p95 653.283 ms，以及导航 7/8 top1、8/8 top5。这支持可用性观察，不构成公开搜索 SLA。
- 最新 `5dd` CI 成功状态来自冻结任务卡；本席未独立下载并复验其全部原始 artifact。
- 未定位 DNS 地址轮换和真实 public-to-private redirect 链的专门测试 fixture。实际 sockaddr 过滤和逐跳实现合理；这是专项证据缺口，不能据此宣称存在 SSRF 绕过。
- 仍需 exact-tag 双平台完整 soak、Windows 11 MSI/ZIP、Linux 包验收、实际 tag attestation，以及对应证据绑定与全平台推广验证。旧 `4cc` soak 和 `10bf` MSI 不能替代。

**最终立场：有条件通过工程推进；最终交付尚未通过。** 建议先修复 A-01、A-02，并以无破坏性的模拟验证仲裁 A-03，再冻结标签候选。无需因此改变既定架构或扩大产品范围。
