评审 ID：**QCWS-CODE-DELIVERY-R1-20261114**  
席位：**Agent A — 需求、架构与技术审查**

**最终立场：不通过本轮最终交付验收。** 核心架构可继续推进；本轮发现三项源码可确认的问题，以及一项需要隔离复现的 P1 风险。冻结任务卡列出的必要交付验收仍未完成，因此不能给予无条件交付认可。

**身份与独立性**

- 我是真实 Codex 原生子代理，任务标识为 `/root/code_review_a_r1`。
- 具体模型 ID、实际推理档位未独立验证；继承父会话设置，不声称已验证最高档位。
- 已完整读取任务卡、快照和委员会协议；未读取其他席位报告，未与其他席交流，未创建辅助评审代理。
- 全程只读；未修改文件、构建、启动服务、安装、部署、提交或推送。未读取禁止的 AGENTS.md、`.codex`、秘密配置或用户 profiles。

**冻结范围与证据**

| 仓库 | 基线 | 冻结 HEAD |
|---|---|---|
| `C:/Dev/github-repos/QCopilots-WebSearch` | `c3025b061a0ec1e3343301e6c07cbe9e81861e14` | `fd5ba2cbce62896624de6e51c628cf5820ae1941` |
| `C:/Dev/github-repos/QGIS` | `84b72dce7a3a66f6b9ac968ce60460d6b498b892` | `aa725ce575be5f4e999bab76e767c05cc8af3355` |

开始及结束检查时，两仓库 HEAD 均与冻结卡一致，工作区均干净。两份补丁 SHA-256 均匹配快照：

- Native：`4b9b2e59634988ce545d5b317b052a2e071ca23e2645f36cb7c565ab2184630b`
- QGIS：`a7231268df0b7eb12a1533fa84fdba3277ba123d69253f20e421f13ae0a5f4b0`

审查覆盖了实际提交差异、核心 C++ 请求/协议/网络/缓存/解析/Windows 实现、QGIS 适配器及共同策略调用链、配置与契约、主要测试、构建与发布脚本、部署和验收脚本。未进行运行时复现，也未对每个辅助脚本逐行穷尽审查。

四份 QGIS 工具 schema 与原生对应文件的 SHA-256 全部一致。QGIS 差异没有修改七项默认启动列表，适配器确实调用现有 `validate_network_url`。

我实际读取的现有证据包括：

- Windows CTest JUnit：6 个 suite，记录 0 failures、0 disabled，包括 core、http-limits、release-assets、tls、stdio-process、windows-security。
- `work/mcp-sdk-windows-v2.json`：记录 `passed: true`。
- `work/portable-windows11-v4.json`：记录 `passed: true`、Windows build 26200/product_type 1、含空格迁移路径、system-only PATH、临时目录已移除。
- 以上 SDK/portable 报告记录的 executable SHA-256 均为 `2be7b85f0807cef17360c45a518ab746be125599c607edec29d7651df2f9da6b`。

这些是读取已有记录，不是本席重新执行测试；也不据此将早期候选包验收升级为冻结最终候选验收。

**四维评分**

| 维度 | 分数 | 依据 |
|---|---:|---|
| 需求可行性 | 8.5 | 范围、接口和主要限制清晰；存在配置契约与实现差异，以及设计承诺尚未落地。 |
| 技术可行性 | 8.0 | 共享服务层、独立控制监听器、实际连接地址检查、身份绑定缓存和单线程 SQL 所有权合理；深层 JSON 资源边界需验证。 |
| 质量可行性 | 7.0 | 针对性测试较充分，但仍有两项行为缺陷，且承诺的分析/fuzz 检查未接入。 |
| 交付可行性 | 6.0 | 包清单、运行时哈希、收据和原子 promotion 设计较完整；必要平台及最终候选验收尚缺。 |
| **等权均分** | **7.4** | `(8.5 + 8.0 + 7.0 + 6.0) / 4 = 7.375 → 7.4` |

**问题表**

| ID | 等级 | 状态 | 问题 |
|---|---|---|---|
| A-01 | P1 | 待验证；危险调用链已确认 | MCP 深层 JSON 在业务准入前发生递归复制，可能使整个原生进程栈耗尽。 |
| A-02 | P2 | 已证实，静态证据 | stdio 请求隐含 20 秒上限，使合法的 21–60 秒配置失效。 |
| A-03 | P2 | 已证实，静态证据 | QGIS 适配器丢弃后端 `retryable`，改变错误契约。 |
| A-04 | P2 | 已证实，需求/实现缺口 | 设计承诺的 Linux sanitizer、静态分析和 fuzz 检查没有实现为 CI 门禁。 |

**A-01 — 深层 MCP JSON 在准入前被递归复制**

- **位置：** `C:/Dev/github-repos/QCopilots-WebSearch/src/protocol.cpp:108`。相关入口为 `src/server.cpp:212`；stdio 另有 `src/server.cpp:353` 按值捕获完整消息。
- **触发条件：** 已认证 HTTP 调用者发送小于 1 MiB 的合法 JSON-RPC 对象；`method`、`id` 类型正常，`params` 是对象，其中含数万层嵌套数组。无需先拥有有效 MCP session，因为 params 复制发生在 session 检查之前。
- **证据与因果链：**
  1. HTTP 入口使用 `Json::parse(req.body, nullptr, false)`，未设置嵌套深度限制。
  2. `validateJsonRpc` 只检查 `params` 顶层为对象。
  3. 第 108 行的 `m.value("params", Json::object())` 返回值并复制整个 params。
  4. 固定依赖 nlohmann/json 3.12.0 的对象/数组复制会复制子 JSON 容器，因此调用栈随嵌套深度增长。此点已核对[该版本上游源码](https://raw.githubusercontent.com/nlohmann/json/v3.12.0/single_include/nlohmann/json.hpp)。
  5. 此路径尚未进入五业务调用准入限制，也不受网络取消轮询保护。
- **影响：** 可能由一个已认证团队调用者造成共享原生服务进程退出，独立控制监听器也随进程失效。1 MiB 字节限制不能等价限制 JSON 嵌套深度。
- **最小建议：** 在 JSON 接收边界、任何递归复制之前加入明确的嵌套深度限制，并对超限输入返回受控错误；同时避免无必要的完整 params/message 复制。不要仅依靠异常捕获处理栈溢出。
- **验证：** 在隔离子进程中对 HTTP 和 stdio 分别发送递增深度、总字节数仍低于上限的 JSON；确认进程存活、返回受控错误、后续健康请求成功。HTTP 可用 `ping` 加深层 `params`，无需真实公网请求。
- **置信度：** 中高。无深度限制、提前完整复制及递归复制机制已确认；本席未执行故障复现，未确认具体构建的崩溃深度，因此不把进程崩溃标为已实测。

**A-02 — stdio 将配置允许的超时截断为 20 秒**

- **位置：** `C:/Dev/github-repos/QCopilots-WebSearch/src/protocol.cpp:221`；根源默认值在 `include/qws/common.hpp:27`。
- **触发条件：** 将 `open_timeout_seconds` 或 `search_timeout_seconds` 配为 21–60 秒，通过 stdio 调用，操作耗时超过 20 秒但未达到配置期限。
- **证据与因果链：**
  1. `config/runtime.schema.json:291`、`:298` 明确允许 1–60 秒。
  2. stdio 调用 `protocol.handle(...)` 时不传取消 token。
  3. 第 221 行生成默认 `CancelToken`，deadline 为创建后 20 秒。
  4. `src/service.cpp:239`、`:444` 使用现有 deadline 与配置 deadline 的较小值，因此无法延长到配置值。
  5. HTTP 入口在 `src/server.cpp:178`、`:221` 显式设置 60 秒初始 deadline，两个传输行为因此不同。
- **影响：** 合法配置对 stdio 不生效；相同配置和工作负载可能在 REST/MCP HTTP 成功、在 stdio 提前超时。
- **最小建议：** 为 stdio 建立与配置兼容的初始期限，再由 Service 按具体操作收紧；保留调用者主动设置的更短期限和取消语义。
- **验证：** 使用已有 `ServiceTransport` 注入点，设置 open 超时 60 秒，在假 open transport 中检查 token 剩余时间，应接近 60 秒而非 20 秒；另验证默认 15/20 秒和较短调用者期限保持正确。
- **置信度：** 高。完整调用链可静态确认；未运行该回归用例。

**A-03 — QGIS 改写后端错误的可重试属性**

- **位置：** `C:/Dev/github-repos/QGIS/python/plugins/qcopilots_mcp_server_web_search/backend_client.py:224`；相关硬编码为同文件 `:36`、`:43`。
- **触发条件：** `web_open` 读取的公网资源返回 500/503 等服务端错误。
- **证据与因果链：**
  1. 原生 `C:/Dev/github-repos/QCopilots-WebSearch/src/network.cpp:403`–`:406` 生成 `upstream_http_error`，并针对 `status >= 500` 设置 `retryable: true`；例如普通 404 则为 false。
  2. QGIS 客户端读取后端错误时只提取 code，再 `raise BackendError(code)`。
  3. `BackendError` 从固定 code 集合重建 retryable；该集合不包含 `upstream_http_error`。
  4. `tools.py:27`–`:28` 将这个重建值返回 MCP 调用者。
- **影响：** 同一个实际错误经 QGIS 适配后从可重试变为不可重试，调用者无法按原生契约实施恢复策略。反向也存在某些原生 `provider_unavailable` 的 false 被改为 true。
- **最小建议：** 对受支持错误 code 保留后端经过类型检查的布尔 `retryable`，继续使用本地安全消息；后端字段缺失或类型错误时才使用本地缺省策略。
- **验证：** 假后端分别返回同一 `upstream_http_error` 的 true/false，验证 MCP 两种结果都原样保留；补充非布尔 retryable 和未知 code 的降级测试。
- **置信度：** 高。原生错误生成与适配器重新生成路径均已确认；未运行新测试。

**A-04 — 已接受的分析与 fuzz 门禁缺失**

- **位置：** `C:/Dev/github-repos/QCopilots-WebSearch/.github/workflows/ci.yml:68`。对应承诺为 `docs/design.md:90`、`:108`；现有 sanitizer 开关在 `CMakeLists.txt:9`，默认 OFF。
- **触发条件：** 普通 CI、完整手动 CI 或 tag 候选构建。
- **证据与因果链：**
  1. 设计明确承诺 Linux CI 运行 ASan/UBSan、静态分析，以及 HTML、URL、JSON-RPC 的有界 libFuzzer smoke；R2 接受 Clang/libFuzzer、clang-tidy 作为 CI 工具。
  2. 实际 CI 仅执行普通配置的 build/test/install 及验收脚本，没有启用 `QCWS_SANITIZERS`，也没有分析/fuzz job。
  3. 已检索 CMake、cmake、scripts、tests、workflow：未发现 `LLVMFuzzerTestOneInput`、fuzzer 编译选项或 clang-tidy 执行配置。
  4. `scripts/verify_release.py:105` 的检查集合也不要求这些检查证据。
- **影响：** 当前 CI 成功并不包含已接受设计所承诺的解析器/内存质量验证；该缺口会直接影响“完整门禁已满足”的交付判断。
- **最小建议：** 在独立 Linux 分析构建中实现这些已承诺的有限检查，并保存结果；使最终候选不能绕过失败或缺失结果。若确需缩减承诺，应先作明确需求仲裁，不能默默将现有普通 CTest 当作替代。
- **验证：** 真实 CI 日志显示 sanitizer 已开启、静态分析实际执行、三个 fuzz 入口及固定语料被运行，并验证检查失败会阻断候选。无需加入普通用户 bootstrap。
- **置信度：** 高。属于实现/门禁缺失，不是在推断 sanitizer 或 fuzz 已发现缺陷。

**关键判断与保留风险**

- 服务与 QGIS 插件的许可及部署边界清楚；适配器没有接管原生服务生命周期。
- 实际 sockaddr 检查、手动重定向处理、禁用运行时代理、TLS 验证、独立身份缓存、上游 permit 生命周期，以及缓存线程串行关闭，构成合理的核心设计。
- 现有测试覆盖了真实 HTTP 输入期限、取消、容量、TLS、缓存失败和进程隔离；这些值得计入质量评分，但不能替代缺失的平台验收。
- 不建议引入新的 Web 框架、额外微服务或重新设计缓存。上述问题可通过局部修正和补齐既定检查解决。
- 没有发现可确认的 P0；没有将 A-01 的潜在崩溃表述为已经复现。

**交付前仍需的证据**

1. 仲裁并验证 A-01；修正或明确裁决 A-02、A-03、A-04，并完成相关回归。
2. 最终同一候选运行时的 Windows/Ubuntu 冷、热各 1800 秒完整长稳结果；旧 TLS 版本长稳仅是基线。
3. Windows 11 **生产 MSI** 的安装、失败事务回滚、升级、配置及 ACL 保持、服务身份、停止和卸载验收，绑定最终候选 MSI SHA-256。工具链 PoC 和只读 MSI 元数据不能替代。
4. 最终候选的 Ubuntu 26.04 CI、DEB 生命周期、Caddy HTTPS 验收；明确区分 GitHub CI 与无法连接的远程主机。
5. 60 条公开 SearXNG 查询及至少一次真实 search/open/find 闭环。合成 provider 的 WebUI/Caddy 测试应继续单独标注。
6. QGIS development/release 两套最终 WebUI 状态、离线恢复及原有配置恢复记录；补齐冻结卡所述进行中步骤。
7. 最终精确源码/包/运行时对应关系、全部 ZIP/MSI/DEB 与来源、许可证、SBOM、哈希及 promotion 验证结果。
8. 三个真实席位针对修正后的同一冻结快照完成复审；本席不替其他席位投票。

本轮可以进入**证据仲裁、最小修正和继续验收**阶段；不能据本报告进入无条件正式交付。
