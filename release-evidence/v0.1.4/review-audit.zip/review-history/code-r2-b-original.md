**结论：有条件通过工程审查，可以继续准备标签候选验收；不能批准最终交付。** 未发现已证实 P0/P1；发现两项 P2 和一项 P3，建议在下一次冻结前完成最小修正。

**身份与独立性**

我是实际 Codex 原生子代理 `/root/code_review_b_r2`，承担委员会 B 席。底层具体模型及 effort 未独立验证，继承当前会话设置。使用了本席两个只读辅助代理检查 QGIS 和交付路径，它们不构成额外投票。未读取其他委员会席位或历史代码评审报告。

**冻结范围及覆盖**

审查前后确认：

- Native HEAD：`5dd5fd67e9baea9ea11993ffb75f81cb1d8af1e6`，工作树干净。
- QGIS HEAD：`52eab8de6674e41537429f0ba22c3b192a744001`，工作树干净。
- 任务卡 SHA256：`a257ff1e7bc77b105fab5477308da816ea9e9a068b91dd6d5835bef5fcb8d4f5`。
- Native 完整补丁 SHA256：`32f73a1b0f9dd279241d790f939d7e895f889ec769efd35611b031b5629f9d5f`。
- QGIS 完整补丁 SHA256：`c513aa95afe22bcbfe468ec54119ffca02a21805522c516ed279f2496253c003`。

Native 完整补丁包含 155 个新增文件；进行了整体读取、文件映射和文本后像核对，深读全部核心 C++ 运行路径及主要配置、测试、bootstrap、打包、安装回滚、证据验证和发布路径。QGIS 完整补丁共 1575 行，覆盖新增适配器、共享生命周期相关调用链、契约、安装与测试注册。四份工具输入契约与 Native 对应文件字节一致。

第三方 Perl JSON 实现及二进制种子/许可证未进行逐行语义审计。未构建、启动服务、安装或修改文件/Git；没有把 Claude 的窄运输 diff 当作完整评审范围。

**四维评分**

| 维度 | 分数 | 依据 |
|---|---:|---|
| 需求可行性 | 8.8 | 四工具、平台、独立服务与 QGIS 边界明确，验收条件可测。 |
| 技术可行性 | 8.7 | 实际连接地址检查、独立控制容量、单线程 SQL、共享搜索取消与独立凭据结构合理。 |
| 质量可行性 | 8.1 | 边界和异常测试较充分，但仍有正文字符损失与代理配置遗漏。 |
| 交付可行性 | 8.0 | 精确产物绑定和完整发布门禁具备；最终标签验收尚未完成。 |
| **等权平均** | **8.4** | `(8.8 + 8.7 + 8.1 + 8.0) / 4`。 |

交付分评价的是继续完成交付的工程准备程度，不表示交付验收已经通过。

**问题 B-01 — P2：HTML 文本节点开头的 U+FEFF 被丢弃**

- **状态**：静态因果链已证实；本席未运行新增复现。
- **位置**：[src/html.cpp:26](C:/Dev/github-repos/QCopilots-WebSearch/src/html.cpp:26)，调用点 [src/html.cpp:434](C:/Dev/github-repos/QCopilots-WebSearch/src/html.cpp:434)。
- **触发**：正文包含 `<p>&#xfeff;word</p>`、`<p>` 后直接跟 UTF-8 `EF BB BF`，或 `<p>pre<span>&#xfeff;word</span></p>`。
- **证据**：整个响应的编码 BOM 已由 `chooseEncoding()` 处理；Lexbor 保留上述正文字符，但 `utf8()` 对每个 DOM 片段重新使用默认 `QString::fromUtf8`，将片段首字符当作 BOM 删除。[test_core.cpp:581](C:/Dev/github-repos/QCopilots-WebSearch/tests/test_core.cpp:581) 已明确证明该 Qt 解码行为。现有 `unicodePageTests` 给 marker 加了控制字符前缀，因此没有覆盖节点首字符的情况。
- **影响**：字符在 HTML 提取阶段已经消失，首次 open 随后缓存错误文本；缓存读取及 literal find 无法恢复。`service.cpp::contentText()` 的修复发生在更晚阶段。
- **最小修复**：DOM 内容解码使用与 `contentText()` 一致的 `QStringDecoder(Utf8, ConvertInitialBom | Stateless)`；保留原始流级 BOM 处理。
- **验证**：为上述三种 HTML 增加提取断言，并覆盖首次 open、缓存读取和 marker 的 literal find；保留真实响应初始 BOM 应被移除的已有测试。
- **置信度**：高；已交叉检查锁定 Lexbor 源码的文本和字符引用处理。

**问题 B-02 — P2：bootstrap 继承遗留 ALL_PROXY/NO_PROXY，覆盖配置意图**

- **状态**：已证实，包含无网络、无文件写入的代理解析检查。
- **位置**：[scripts/pipeline.py:49](C:/Dev/github-repos/QCopilots-WebSearch/scripts/pipeline.py:49)，下载调用 [scripts/pipeline.py:103](C:/Dev/github-repos/QCopilots-WebSearch/scripts/pipeline.py:103)，契约 [BuildPipeline.schema.json:61](C:/Dev/github-repos/QCopilots-WebSearch/config/BuildPipeline.schema.json:61)。
- **触发**：profile 设置 `proxy=""`，但宿主环境存在 `ALL_PROXY/all_proxy`；或配置指定代理，但遗留 `NO_PROXY/no_proxy` 包含 PyPI。
- **证据**：`self.env` 复制宿主环境后只覆盖四个 HTTP(S) 变量，pip download 使用该环境。受控解析显示：空 HTTP(S) 配置仍选择 `ALL_PROXY`；指定 HTTP(S) 代理可被 `NO_PROXY=pypi.org` 绕过。APT 路径已经完整清理这些变量，pip 路径尚未清理。
- **影响**：“空值直连”不成立；旧代理失效或网络必须经指定代理时，bootstrap 可能失败。依赖哈希校验仍有效，不认定为包内容篡改。
- **最小修复**：构造下载环境时清除大小写 `ALL_PROXY` 和 `NO_PROXY`，再应用 profile 代理值。
- **验证**：添加纯环境解析测试，覆盖空代理＋遗留 ALL_PROXY、指定代理＋遗留 NO_PROXY，并保留现有 APT 测试。
- **置信度**：高。

**问题 B-03 — P3：Web Search 端口说明与实际默认值不一致**

- **状态**：已证实。
- **位置**：[qcopilots_service.schema.json:78](C:/Dev/github-repos/QGIS/python/plugins/qcopilots_mcp_server_web_search/qcopilots_service.schema.json:78)。
- **触发**：用户根据 schema 编辑器提示配置或排查端口。
- **证据**：说明写“Web Search 48211”；manifest、README 和 `DEFAULT_SERVICE_PORTS` 均指定 Web Search 为 `48218`，`48211` 属于 Builtin Tools。
- **影响**：误导配置或排查；不影响当前实际默认值。
- **最小修复**：更正文案为 Web Search `48218`，或只保留通用端口约束。
- **验证**：静态核对常量、manifest 与说明一致即可，无需新增运行测试。
- **置信度**：高。

**已核查的关键实现**

共享搜索任务的上游容量保持到实际结束，单个等待者取消不会取消仍有等待者的工作。缓存访问由单一 Qt 线程执行，调度与关闭串行，失败事务不会清除尚未持久化的 LRU 更新。JSON 深度预检、stdio 有界输出及阻塞写关闭、DELETE 重复/错误协议头检查具备对应实现和回归覆盖。

QGIS 保留现有生命周期及七项启动默认集合，后端失效时仍可发现工具，后端恢复无需管理原生服务生命周期。发布路径绑定 commit、运行、包哈希和运行时指纹，先核验完整 draft 资产再公开，未发现将旧 soak 自动当作新标签证据的路径。

**证据限制与后续门禁**

我读取了 `bom-before.log`、`bom-after.log`：现有 Unicode 回归确实先失败，修复后 Windows CTest 为 7/7。这证明已修路径，不覆盖 B-01 的新边界。

读取的 Windows MSI result 显示 exact `10bf` 包通过、停止耗时约 0.263 秒且 CleanupErrors 为空；它不能认证未来标签包。ZIP SDK 与 QGIS WebUI 证据也只能支持各自记录的源版本和运行范围。QGIS development 原始 helper 的失败及独立 cleanup recovery 必须继续保留，不能改写为原 helper 全部成功。

最终交付仍需：

1. 下载并复核 latest `5dd` CI 原始产物与结果。
2. 对最终精确标签产物完成 Windows 11、Ubuntu 26.04 完整 cold/hot soak。
3. 完成精确标签 Windows MSI/ZIP 及 Linux 安装、升级、恢复验收。
4. 成功完成标签 attestation 和完整资产 promotion 校验。
5. 对 B-01/B-02 修正后的快照补充相关回归；若不修，明确接受其残余影响。

**最终立场：有条件通过。** 可以继续工程工作及候选验收准备，建议先修 B-01/B-02 再冻结标签候选，避免重新生成整套验收证据；最终交付保持未批准状态。
