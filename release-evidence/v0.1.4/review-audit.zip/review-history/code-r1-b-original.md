Agent B 正式原始报告
Review ID: QCWS-CODE-DELIVERY-R1-20261114

身份与范围
- 席位：真实 Codex 子代理 /root/council_design_b，质量与交付主审。模型和 reasoning effort 继承当前会话，未从可验证运行元数据独立确认，因此不宣称具体型号或最高档位。
- 只读审查原生仓库 C:/Dev/github-repos/QCopilots-WebSearch 的 c3025b061a0ec1e3343301e6c07cbe9e81861e14..fd5ba2cbce62896624de6e51c628cf5820ae1941，以及 QGIS 仓库 C:/Dev/github-repos/QGIS 的 84b72dce7a3a66f6b9ac968ce60460d6b498b892..aa725ce575be5f4e999bab76e767c05cc8af3355。前者 95 个文件，后者 25 个文件。结束时两仓库 HEAD 未变，git status --porcelain=v1 -uall 均为空。
- 已读任务卡、委员会协议、核心 C++ 服务/缓存/网络/HTML/MCP/HTTP/进程入口、相关测试及配置契约，并核对交付脚本/工作流和 QGIS 适配。使用两个只读事实助手 /root/council_design_b/delivery_facts 和 /root/council_design_b/qgis_facts，分别辅助交付与适配事实搜集，它们不构成额外投票席位。下列问题已由本人重新核对源码。
- 未读取其他席报告，未读取禁止的 AGENTS.md/.codex、secret 或忽略运行配置。未写文件，未运行构建/安装/服务/测试。本轮属于代码及交付评审，不沿用设计轮评分。

评分
| 维度 | 分数 | 依据 |
|---|---:|---|
| 需求 | 8.8 | 四工具、三入口、身份隔离、出站限制和 QGIS 最小集成有对应实现，批准的额外质量检查尚未全部落地 |
| 技术 | 8.7 | 共享服务契约、独立控制监听、实际连接地址校验、专用 SQL 线程、会话与工作容量边界合理，官方 SDK 报告提供互操作支持 |
| 质量 | 8.1 | 确定性边界与失败路径测试较扎实，独立审读未确认核心 P0/P1，缺少已承诺的 sanitizer/static/fuzz CI，最终稳定性证据尚未完整 |
| 交付 | 6.7 | 精确产物的验证和完整发布门禁设计已实现，但生产 Win11 MSI、最终版本双平台验收与公网闭环尚未完成，Ubuntu 代理 bootstrap 另有条件性缺陷 |
| 等权综合 | 8.1 | (8.8 + 8.7 + 8.1 + 6.7) / 4 = 8.075，保留一位小数 |

已确认问题（本 Review ID 下的新 B 编号）

B-01 — P2 — 已证实的工程检查缺口
位置：C:/Dev/github-repos/QCopilots-WebSearch/.github/workflows/ci.yml:23、:68，C:/Dev/github-repos/QCopilots-WebSearch/CMakeLists.txt:9、:43。需求依据为 C:/Dev/github-repos/QCopilots-WebSearch/docs/design.md:90、:108。
触发：任何 PR/push CI，包括修改 HTML、URL 或 JSON-RPC 解析器的变更。
证据：冻结设计明确承诺 Linux ASan/UBSan、static analysis、HTML/URL/JSON-RPC bounded libFuzzer smoke，且指定 CI-only Clang/clang-tidy。实际工作流只有普通 Windows/Ubuntu 构建与验收。QCWS_SANITIZERS 默认 OFF，工作流未启用。搜索 CMake、cmake、scripts、tests、.github 后未找到 clang-tidy 调用或 fuzz 目标/语料。
影响：宣称的质量门禁未执行，解析器/并发相关回归只有当前确定性样例覆盖。这是覆盖与需求落实问题，不等同于已经发现内存漏洞。
最小建议：增加独立 Ubuntu 分析任务，启用已有 sanitizer 配置并运行相关测试，接入可失败的 clang-tidy 和三个有固定时间/内存上限的 parser fuzz smoke 目标。保留非敏感 corpus 及产物诊断，不改变普通用户 bootstrap。
验证：从 PR CI 记录实际编译选项、分析命令和三目标运行结果，加入能证明错误会导致任务失败的受控验证。补充 design.md:90 的并发页面与五客户端突发检查时，明确区分其结果与 2 请求/秒 soak。
置信度：高，直接静态证据。未实测新任务。

B-02 — P2 — 已证实的条件路径缺陷（静态推导，尚无 Ubuntu 实机复现）
位置：C:/Dev/github-repos/QCopilots-WebSearch/scripts/pipeline.py:36、:157、:158、:159。契约依据为 C:/Dev/github-repos/QCopilots-WebSearch/config/BuildPipeline.schema.json:59 和 C:/Dev/github-repos/QCopilots-WebSearch/docs/build.md:51。
触发：以普通用户执行 Ubuntu bootstrap，缺少系统依赖，镜像必须经 profile.proxy 访问，sudo 的 env_reset 生效且没有为代理变量设置 env_keep 或系统级 apt 代理。
证据：profile.proxy 仅写入 Pipeline.env 的四个代理环境变量。缺包路径随后执行 sudo -n apt-get update/install，没有给 apt 显式代理参数，也没有选择性保留这些变量。sudo 官方说明确认默认新建最小环境，并由 env_keep 控制保留变量：[sudo 官方故障排查](https://github.com/sudo-project/sudo/blob/main/docs/TROUBLESHOOTING.md?plain=1)。
影响：同一配置的 Qt/Python 下载可使用代理，但系统包安装阶段失去代理而失败，阻断受限网络下的一键环境准备。
最小建议：为 update 和 install 显式传递与配置一致的 Acquire::http::Proxy / Acquire::https::Proxy 参数，或仅保留必要代理变量。不要使用宽泛 sudo -E。空代理保持明确直连语义，offline 缺包继续立即报错。
验证：在隔离 Ubuntu 或能清理环境的 sudo fixture 下验证 apt 实际收到代理，覆盖 root/非 root、空代理和 offline 分支。无需修改用户 sudoers。
置信度：高，条件明确且调用链可见。没有把未运行的实机复现写成通过或失败。

B-03 — P3 — 已证实的文档与实现不一致，非阻断建议
位置：C:/Dev/github-repos/QCopilots-WebSearch/docs/design.md:92，对照 C:/Dev/github-repos/QCopilots-WebSearch/.github/workflows/ci.yml:17、C:/Dev/github-repos/QCopilots-WebSearch/.github/workflows/release.yml:26。
触发：按设计文档核验发布供应链声明。
证据：设计明确提到 GitHub artifact attestations，但冻结 CI/发布流程没有生成或验证 GitHub attestations 的步骤。现有实现是 artifact digest、包 hash 和项目自行生成的 provenance/receipt 绑定。
影响：文档承诺超过当前实现。现有校验链仍有价值，此项不构成已证实的发布篡改漏洞。
最小建议：在交付记录中准确区分已实现的摘要/receipt 与尚未实现的 GitHub 签发证明。若继续保留该设计承诺，补齐生成与验证步骤。
验证：要么有实际 attestation 及验证日志，要么文档明确标记该能力未实现，不把自生成 provenance 当作 GitHub attestation。
置信度：高，静态事实。P3 默认不阻断。

未发现达到证据标准的 P0/P1 代码缺陷。QGIS 四份工具 schema 与原生版本相同，固定 REST 路由、contract_version 检查、错误映射和分离令牌一致。formal_restricted 仍经原公共网络策略，Manager 原默认启动列表未改。后台不可用不阻断工具发现。QGIS TLS 专用单测采用模拟失败，未提供自动跨仓库 schema 漂移检查，这些是覆盖边界，不另定性为缺陷。

核验到的正面证据与限度
- 只读解析当前 native build/windows-x64/test-results.xml，记录 6 suites、0 failures。相关代码确实覆盖临时目录/动态端口、5 请求屏障与第 6 个拒绝、共享检索单个/全部取消、压缩与解压超限、cache BUSY/FULL/损坏、协议生命周期、HTTP 输入期限与实际 TLS fixture。没有声称本人重新运行。
- 读取任务卡允许的 work/mcp-sdk-windows-v2.json，HTTP/stdio 均 passed，取消约 0.201/0.217 秒，子进程正常停止，无公网尝试。
- 读取 work/portable-windows11-v4.json，Windows workstation product_type=1、build26200，relocated_path_with_spaces 与 system_only_path 为 true，forced_process_count=0。该报告明确 public.attempted=false。它不能替代公网或生产 MSI 验收。
- 发布脚本静态证据链覆盖同仓库成功 CI、精确源提交、artifact digest、包 hash、构建/测试/安装 receipt、运行库指纹、外部 Win11 报告，以及 draft 发布后逐项回验。未确认新的 fail-open。
- 任务卡说明最新本地 ZIP/MSI 候选是 5f62dea，不能直接当作 fd5ba2c 最终发布证据。早先 c004dc2 CI 及冻结时仍在验证的 2e00dbe CI 也不能替代最终同一快照。

仍需完成的交付门禁（已知未完成项，不伪装成新代码 Bug）
1. 对修正后的同一不可变源提交运行 Windows/Ubuntu CI，包含 B-01 的实际分析检查。对最终待发布字节生成完整 ZIP/MSI/DEB、SBOM、hash、source 与 receipts。
2. Windows 11 对最终候选 MSI 完成生产服务安装、真实虚拟账户权限、失败事务回滚、升级、配置保留、停止/恢复/卸载与清理。现有 MSI metadata/AST 和早期 probe 不替代此门禁。
3. 最终 runtime 的冷/热各 1800 秒稳定性，明确宿主资源、p95/RSS/健康延迟和 ≤10 秒停止，保留 exact runtime/package binding。冻结时运行中的报告未完成前不能计为通过。
4. 最终 Ubuntu DEB lifecycle 与 Caddy HTTPS 合约结果，以及各 30 条中英文真实 SearXNG 查询和至少一条实际搜索→阅读→查找闭环。成功率仍按尽力而为报告，但模拟上游或直接 IP 阅读不替代真实搜索闭环。
5. QGIS 开发/发布双链路所有要求，包括开发 read/find、发布后端停机/恢复及 WebUI 原配置恢复、临时服务移除和本轮进程清理。已描述的部分成功只计相应步骤。
6. 保留委员会同一最终快照的三席原始结果与仲裁记录，再批准发布。ethanyang 未连通应继续标记无该机证据，不把 CI 写成远端实机。

最终立场
需求、技术和质量方向可继续推进，B-01/B-02 应修正并验证，B-03 可按低优先级处理。对“最终团队级交付完成”本轮结论为未通过，因为必要安装与最终产物验收仍缺失。允许进入最小修正和补验阶段，当前不建议正式发布，也不认可“所有测试及三席交付门禁已经通过”的表述。该立场并不推定未运行的 MSI 或公网测试必然失败。

独立性审计补充：本轮可见上下文中未看到 A/C 席或其辅助任务的发现摘要，也未向其交流。我调用的 list_agents 明确限定 path_prefix=/root/council_design_b，结果只有本席与自己的 delivery_facts、qgis_facts 两个事实助手。收到的 C 席信息仅为你提供的 ENAMETOOLONG 与改用完整冻结补丁的启动/范围说明，没有其发现或评分。上述完整正式原始报告已发回，评分为 8.8/8.7/8.1/6.7，综合 8.1。
