from pathlib import Path, PurePosixPath
import base64, hashlib, json, subprocess, sys, zipfile
root = Path(__file__).resolve().parents[1]
folder = root / 'work/council/r4-input/checkonly'
archive = folder / 'artifact.zip'
def sha(raw): return hashlib.sha256(raw).hexdigest()
assert sha(archive.read_bytes()) == '46ea01f00927d8c735e25ea684635d7c9afe383b5a2f48b7833ca5cb33b488a4'
destination = folder / 'extracted'
destination.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as source:
    entries = source.infolist()
    assert len(entries) == len({i.filename for i in entries}) == 8
    for item in entries:
        p = PurePosixPath(item.filename)
        assert not p.is_absolute() and '..' not in p.parts and ':' not in item.filename
        target = destination.joinpath(*p.parts)
        target.parent.mkdir(exist_ok=True, parents=True)
        raw = source.read(item)
        if target.exists(): assert target.read_bytes() == raw
        else: target.write_bytes(raw)
result = json.loads((destination / 'publication-result.json').read_bytes())
proof = json.loads((destination / 'publication/publication-proof.json').read_bytes())
assert result['check_only'] is True and result['published'] is False and result['release_id'] == 446672881
assert result['source_commit'] == '3e13f7bd930ffa495e14d50c3556028a21484204'
assert proof['tools']['commit'] == 'bead1999fbdb1200fdb8dec6f3c3df803898c0b3'
assert len(result['existing_assets_verified']) == 25
assert result['incomplete_assets_identified'] == {'qtbase-everywhere-src-6.12.0.tar.xz': 753715322}
zpath = destination / 'publication/quality-evidence.zip'
assert sha(zpath.read_bytes()) == proof['archive_sha256'] == result['assets']['quality-evidence.zip']
with zipfile.ZipFile(zpath) as archive:
    assert len(archive.infolist()) == len(set(archive.namelist())) == 44
    assert set(archive.namelist()) == set(proof['archive_members'])
    for name, item in proof['archive_members'].items():
        raw = archive.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256'] == proof['logical_files'][name]
    assert set(proof['archived_empty_logs']) == {'quality-001-git-clean-before.log', 'quality-032-git-clean-after.log'}
    assert all(archive.read(n) == b'' for n in proof['archived_empty_logs'])
    for name in ('release-manifest.json', 'SHA256SUMS'):
        assert archive.read(name) == (destination / 'verified-original' / name).read_bytes()
command = [sys.executable, str(root / 'work/gh_authenticated.py'), 'api']
draft = json.loads(subprocess.check_output(command + ['repos/xiaobing318/QCopilots-WebSearch/releases/446672881']))
assert draft['draft'] is True and draft['published_at'] is None and len(draft['assets']) == 25
current = [{k:a.get(k) for k in ('id', 'name', 'size', 'state', 'digest')} for a in draft['assets']]
original = json.loads((root / 'work/release-43805306130/promotion-partial-draft.json').read_bytes())
if 'assets' not in original:
    raise RuntimeError('Unexpected original draft evidence structure')
before = [{k:a.get(k) for k in ('id', 'name', 'size', 'state', 'digest')} for a in original['assets']]
assert sorted(current, key=lambda a:a['id']) == sorted(before, key=lambda a:a['id'])
all_assets = json.loads(subprocess.check_output(command + ['repos/xiaobing318/QCopilots-WebSearch/releases/446672881/assets?per_page=100']))
assert len(all_assets) == 26
starters = [{k:a.get(k) for k in ('id','name','size','state','digest')} for a in all_assets if a['state'] != 'uploaded']
assert starters == proof['recovery']['incomplete_assets']
(folder / 'all-assets-after.json').write_text(json.dumps(all_assets, indent=2)+'\n', encoding='utf-8')
(folder / 'draft-after.json').write_text(json.dumps(draft, indent=2)+'\n', encoding='utf-8')
record = {'run_id':43821974116, 'conclusion':'success', 'artifact_sha256':sha((folder/'artifact.zip').read_bytes()),
          'source_commit':result['source_commit'], 'tools_commit':proof['tools']['commit'],
          'existing_uploaded_assets_downloaded_and_verified':25, 'starter_identified_separately':result['incomplete_assets_identified'],
          'uploaded_asset_identities_unchanged_from_failed_run':True, 'starter_identity_matches_fixed_record':True,
          'physical_asset_count':len(result['assets']),
          'quality_archive_members':44, 'exact_empty_log_members':proof['archived_empty_logs'],
          'published':False, 'product_rebuilt':False}
(folder / 'verification.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record, indent=2))
