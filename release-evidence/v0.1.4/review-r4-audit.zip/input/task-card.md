# R4 — 发布传输和中断草稿恢复追加评审

Review ID: QCWS-v0.1.4-R4-transport-20261116
Mode: 代码、方案、交付综合评审，仅覆盖本次发布恢复。

用户明确允许在原三轮上限后追加一次，并明确禁止调用Claude Code（额度耗尽）。本轮A/B/C均为真实独立Codex子代理，C是公开披露的替代席位，不是Claude，不宣称跨供应商独立性。模型和推理档位继承当前会话、未独立验证。不要读取其他席位报告或向其他席位发送观点。主代理唯一可写，三席只读。

Repository: C:/Dev/github-repos/QCopilots-WebSearch
Git HEAD: bead1999fbdb1200fdb8dec6f3c3df803898c0b3
Base: 5849ac30f51d4a39305a108f145b22e6a710b462
Branch: implementation/navigation-validation
Remote tool branch: release/v0.1.4-transport
Working-tree baseline: clean
Snapshot: 本目录snapshot.json、scope.patch，SHA256在snapshot中。审查期间禁止修改范围内文件。
Sensitive-data decision: 仅公开源码和脱敏证据。禁止Claude工具，禁止读取凭据。
Max rounds: 原R1-R3已完成，本轮是用户额外授权的一轮R4。

## 背景与目标

v0.1.4源码固定3e13f7bd930ffa495e14d50c3556028a21484204，CI43805306130 attempt1双平台成功，既有Windows11/MSI/ZIP、UbuntuDEB、各300秒冷/热稳定性及最终发布版QGIS验收已完成。旧R3已对这些产品字节允许受控发布。本次不重新评审完整C++产品，也不重新编译或移动标签。QGIS f69eeed3fe141c13bdc0339aa3ee43ea3c3d6c4d不改。

原正式推广43815745697执行全部门禁及Sigstore检查后，在上传两个正常0字节git-clean日志时HTTP400。草稿446672881未发布。实际共有26资产，其中25uploaded，另一个Qt源码qtbase-everywhere-src-6.12.0.tar.xz是starter占位（ID753715322，size51220268，digest=null）。旧SHA256SUMS资产ID753715225，SHA256 b7fb7c70ddc0210e31d2509543a524acb183750074f77737f8643fdc6c796965。

修正将原候选自己的promote_release.py在独立原始检出执行而不传--Publish，原门禁和三包签名验证完整保留。另目录生成physical布局，所有quality文件和原manifest/SHA256SUMS在确定性ZIP_STORED归档，0字节日志仍为0字节成员，非空quality仍单独发布。physical manifest+proof+SHA256SUMS映射逻辑与物理证据。原安装包、源代码归档、SBOM、测试结果字节不变。

恢复仅针对确切draft/tag/commit。25个uploaded按ID下载核验，只有原旧SHA256SUMS ID+SHA允许替换。固定ToolsCommit中的sidecar只允许清除确切starter占位并补传原始已验证Qt源码。其他starter、异名或异字节资产拒绝。完整上传后重新下载所有资产、逐字核对归档成员，再检查草稿/标签/资产集后发布。CheckOnly不得产生远端创建、删除、上传、发布操作。

## 同一轮证据及验收条件

本地Windows测试：work/release-r4-tests-2.log，50项release*.py通过。全部测试临时目录与模拟远端，无真实安装包测试冒称。初版14项在python -O通过，新增占位测试另在本轮日志中。真实Ubuntu只读预演43821492636正确拒绝未知starter且未修改草稿，其日志在work/release-43805306130/checkonly-43821492636.log。

最终同源码预演run43821974116（job133146895277）正在执行，预演只读重新验证所有原候选门禁、来源和真实草稿资产。该运行ID和工具commit在本任务卡固定，其完成后的日志/制品会写入本目录checkonly/作为证据补充，不改变候审源码或本任务卡。请在最终投票前读取其结论或等待主代理提供同一运行的原始证据。不得把未完成当通过。

原始用户接受的产品证据commit5849ac30f51d4a39305a108f145b22e6a710b462，release-evidence/v0.1.4/windows11.json SHA256 5f2d1d53f98cfcf55b0984da22d6f260ab78439da60fb324eeeedb67c0d598bf。它和原R3audit保持原字节。不需要阅读其他评审原文来形成独立R4意见。

关键验收：原门禁不削弱、已验收字节不改变、空日志证据无损、精确草稿恢复、失败不发布、CheckOnly零变更、重复运行正确拒绝或安全复用、真实Ubuntu执行、全量发布后下载仍为正式发布前条件。GitHub API跨请求没有事务，工作流锁不控制其他管理员，受控发布期间由主代理作为唯一写入者，残余竞态不能被宣称消除。

## 排除范围

不重跑C++构建/安装/稳定性。QGIS和Materials不改且不读其AGENTS.md或.codex。产品遗留stdout fixture需下一标签修复、QGIS初始白屏根因未证实、尽力而为公网部分失败、未签名等旧R3限制继续保留，不以本次运输修正掩盖或重新扩展。不得更改Git/远端/用户应用，不调用Claude。

## 每席输出

覆盖所有适用门禁，职责分别侧重A需求架构、B正确性测试交付、C独立失败模式挑战。允许只读执行隔离测试，不改仓库。

返回真实身份/模型档位未知说明、范围与遗漏、需求/技术/质量/交付四个0-10评分及等权一位小数总分、问题表（ID/P0-P3/状态/位置/触发/证据/影响/最小建议/验证/可信度）、风险与简化方案、立场（通过/有条件通过/不通过/无法完成）、还需哪些证据。没有实证问题可空表，不能为评分制造问题。明确是否认可主代理在同工具commit、相同候选/证据/恢复参数下从CheckOnly转入实际上传和受控发布。发布后的真实全资产验证仍由代码强制执行。
