Message Type: FINAL_ANSWER
Task name: /root
Sender: /root/code_review_c_r4
Payload:
C 席结论：**有条件通过，认可按相同工具提交、候选、证据与恢复参数转入实际上传和受控发布。** 无 P0/P1 问题；发现一项不影响资产完整性门禁的 P2 状态报告问题。

身份：真实独立 Codex C 席，公开替代 Claude；未调用 Claude。模型及推理档位继承、未独立验证。未阅读其他席位报告，未修改源码、工作区或远端。

| 维度 | 分数 | 依据 |
|---|---:|---|
| 需求 | 9.3 | 保留已验收候选字节及原门禁；空日志无损；恢复身份限定明确 |
| 技术 | 9.0 | 校验先于删除和上传，按资产 ID 操作，发布前全量下载复核；最终提交仍存在网络状态歧义 |
| 质量 | 9.1 | 独立重跑 50 项通过；17 项传输测试在 `-O` 下通过；补充失败注入符合预期 |
| 交付 | 8.8 | 同源码真实 Ubuntu CheckOnly 成功，证据绑定完整；实际上传及发布尚未执行 |
| **等权总分** | **9.1** | 四项平均，保留一位小数 |

已核实的证据：

- HEAD 为 `bead1999fbdb1200fdb8dec6f3c3df803898c0b3`，补丁及八个范围文件 SHA256 均匹配快照；结束时工作区仍 clean。
- 候选提交的原 `promote_release.py` 与 base 中对应文件完全相同。新入口在独立候选检出执行该脚本，未传 `--Publish`；原验收及三包 Sigstore 验证保留。
- 真实 Ubuntu 运行 [43821974116](https://github.com/xiaobing318/QCopilots-WebSearch/actions/runs/43821974116) 的原始日志确认同一工具 HEAD、相同恢复参数、17 项测试通过、原候选验证完成，最终输出 `Verified without remote mutation`。
- 独立验证 artifact ZIP SHA256 为 `46ea01f00927d8c735e25ea684635d7c9afe383b5a2f48b7833ca5cb33b488a4`；工具文件哈希对应固定 Git blobs，候选 verifier 哈希对应候选提交。
- 核对 80 项 physical inventory 的证据映射；归档全部 44 个成员哈希、类型、ZIP_STORED、原 manifest/checksums 字节一致。两个 git-clean 日志确为零字节成员。
- CheckOnly 实际核验 25 个 uploaded 资产；Qt `starter` ID `753715322` 单独标识，未冒称其内容已下载。运行后 release `446672881` 仍为 draft，完整资产列表为 26 项。
- 使用指定 SDK Python 独立重跑 50 项 release 测试通过。最初普通 Python 缺少 `psutil` 的环境问题已通过正确解释器解决。
- 额外内存模拟证明：删除失败、删除已生效但响应丢失、上传中断都不会调用发布；新产生的未知 starter 在重试时被拒绝，未发生新写入。

问题表：

| ID | 等级 | 状态 | 位置 | 触发 | 证据 | 影响 | 最小建议 | 验证 | 可信度 |
|---|---|---|---|---|---|---|---|---|---|
| C-R4-01 | P2 | 已复现；非资产完整性阻断 | [release.md](/C:/Dev/github-repos/QCopilots-WebSearch/docs/release.md:141)、[release_transport.py](/C:/Dev/github-repos/QCopilots-WebSearch/scripts/release_transport.py:342) | 发布 PATCH 已生效但响应丢失，或随后 GET 失败 | 两种独立失败注入均得到异常退出且 `draft=False`；发布前资产验证已完成 | 文档“A failed operation leaves a draft”过宽；操作者可能误判发布结果或盲目重试 | 明确仅发布请求之前的失败保证不发布；最终阶段报错须先只读核对同一 release ID、tag、资产集，再决定后续行动。无需为此改动本次固定源码才能发布 | 故障注入输出分别为 `publish_ack_lost ... draft=False`、`final_get_fails ... draft=False` | 高 |

范围与限制：覆盖本次 workflow、原 verifier 调用边界、布局转换、校验、恢复、重试及发布状态机。未重跑 C++、安装与稳定性验收，未访问 QGIS/Materials 指令或凭据。传输模拟没有被当作产品验收，也没有把 CheckOnly 当作实际上传测试。

发布认可的条件是：保持上述固定提交和参数，由主代理作为唯一写入者；保留代码强制的**上传后、正式发布前**全量下载与归档成员核验；最终发布阶段若异常，按 C-R4-01 先核对远端事实。GitHub 跨请求竞态仍然存在，工作流锁不能约束其他管理员。

当前无须追加预演或重建。实际运行后仍需留存发布结果、全部资产核验结果和最终 release 身份证据；这些是交付闭环，不能预先宣称完成。