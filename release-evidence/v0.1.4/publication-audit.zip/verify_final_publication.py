"""Independently bind final workflow receipts to the public Release inventory."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile
root=Path(__file__).resolve().parents[1]
folder=root/'work/release-43805306130/publication-43823293370'
def read(name): return json.loads((folder/name).read_bytes())
def sha(raw): return hashlib.sha256(raw).hexdigest()
run=read('run.json')
assert run['id']==43823293370 and run['status']=='completed' and run['conclusion']=='success'
assert run['head_sha']=='bead1999fbdb1200fdb8dec6f3c3df803898c0b3'
entry,=read('artifact-metadata.json')['artifacts']
raw=(folder/'artifact.zip').read_bytes()
assert entry['digest']=='sha256:'+sha(raw) and entry['workflow_run']['id']==run['id']
destination=folder/'extracted'
destination.mkdir(exist_ok=True)
with zipfile.ZipFile(folder/'artifact.zip') as archive:
    entries=archive.infolist()
    assert len(entries)==len({i.filename for i in entries})==8
    for item in entries:
        p=PurePosixPath(item.filename)
        assert not p.is_absolute() and '..' not in p.parts and ':' not in item.filename
        target=destination.joinpath(*p.parts)
        target.parent.mkdir(parents=True,exist_ok=True)
        content=archive.read(item)
        if target.exists(): assert target.read_bytes()==content
        else: target.write_bytes(content)
result=json.loads((destination/'publication-result.json').read_bytes())
preflight=json.loads((root/'work/council/r4-input/checkonly/extracted/publication-result.json').read_bytes())
assert result['published'] is True and result['assets']==preflight['assets']
assert result['release_id']==446672881 and result['tag']=='v0.1.4'
assert result['source_commit']=='3e13f7bd930ffa495e14d50c3556028a21484204'
assert result['replaced_checksum_asset_id']==753715225
assert result['replaced_incomplete_assets']=={'qtbase-everywhere-src-6.12.0.tar.xz':753715322}
proof=json.loads((destination/'publication/publication-proof.json').read_bytes())
assert proof['tools']['commit']==run['head_sha']
assert proof==json.loads((root/'work/council/r4-input/checkonly/extracted/publication/publication-proof.json').read_bytes())
with zipfile.ZipFile(destination/'publication/quality-evidence.zip') as archive:
    assert len(archive.infolist())==len(set(archive.namelist()))==44
    for name,item in proof['archive_members'].items():
        raw=archive.read(name)
        assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
    assert all(archive.read(n)==b'' for n in proof['archived_empty_logs'])
release=read('release.json')
assert release['id']==446672881 and release['draft'] is False and release['published_at']
assert release['tag_name']==result['tag'] and release['target_commitish']==result['source_commit']
assets=read('assets.json')
assert len(assets)==len({a['id'] for a in assets})==len({a['name'] for a in assets})==80
assert all(a['state']=='uploaded' and a['size']>0 for a in assets)
assert {a['name']:a['digest'] for a in assets}=={n:'sha256:'+v for n,v in result['assets'].items()}
prior=json.loads((root/'work/council/r4-input/checkonly/all-assets-after.json').read_bytes())
current={a['name']:a for a in assets}
reused=[]
for a in prior:
    if a['state']=='uploaded' and a['name']!='SHA256SUMS':
        assert current[a['name']]['id']==a['id'] and current[a['name']]['digest']==a['digest']
        reused.append(a['name'])
assert len(reused)==24
record={'release_id':release['id'],'url':release['html_url'],'published_at':release['published_at'],
        'tag':result['tag'],'source_commit':result['source_commit'],'tools_commit':run['head_sha'],
        'candidate_ci_run':43805306130,'publication_run':run['id'],'publication_run_conclusion':run['conclusion'],
        'r4_evidence_commit':'ff47cada5228e9ac18a686f27fc5ab83fa004162',
        'artifact_sha256':entry['digest'].removeprefix('sha256:'),
        'all_80_assets_downloaded_and_hashed_before_publication':True,
        'public_api_all_80_names_sizes_states_digests_match_workflow_receipt':True,
        'physical_inventory_equals_successful_checkonly':True,'unchanged_uploaded_assets_reused_by_id':24,
        'quality_archive_members':44,'preserved_zero_byte_log_members':proof['archived_empty_logs'],
        'replaced_old_checksums_id':result['replaced_checksum_asset_id'],
        'replaced_recorded_starters':result['replaced_incomplete_assets'],
        'product_rebuilt':False,'tag_moved':False,'signed_windows_packages':False}
(folder/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record,indent=2))
